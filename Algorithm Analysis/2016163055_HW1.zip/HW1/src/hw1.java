import java.io.*;

public class hw1 {

    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            fr = new FileReader("C:\\hw1\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw1\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                s = br.readLine();
                String[] line = s.split(" ");
                int n = Integer.parseInt(line[0]);
                int h = Integer.parseInt(line[1]);
                s = br.readLine();
                line = s.split(" ");
                boolean[][][] index = new boolean[n][n][n];
                for(int a = 0; a < n; a++) {
                    for (int b = 0; b < n; b++) {
                        for (int c = 0; c < n; c++) {
                            index[a][b][c] = false;
                        }
                    }
                }
                for(int j = 0; j < h; j++){
                    int x = Integer.parseInt(line[3*j]);
                    int y = Integer.parseInt(line[3*j+1]);
                    int z = Integer.parseInt(line[3*j+2]);
                    if(z == 0){
                        for(int k = 0; k < n; k++){
                            index[x][y][k] = true;
                        }
                    }
                    else if(y == 0){
                        for(int k = 0; k < n; k++){
                            index[x][k][z] = true;
                        }
                    }
                    else{
                        for(int k = 0; k < n; k++){
                            index[k][y][z] = true;
                        }
                    }
                }
                int num = 0;
                for(int a = 0; a < n; a++) {
                    for (int b = 0; b < n; b++) {
                        for (int c = 0; c < n; c++) {
                            if(!index[a][b][c])num++;
                        }
                    }
                }
                bw.write("#"+(i+1)+" "+num);
                bw.newLine();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}
