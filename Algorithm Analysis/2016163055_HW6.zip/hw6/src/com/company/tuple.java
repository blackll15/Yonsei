package com.company;

public class tuple {
    int n;
    int m;
    float[][] A;
    float[] B;
    float[] C;
    float v;
    public tuple(int n, int m, float[][] A, float[] B, float[] C, float v){
        this.n = n;
        this.m = m;
        this.A = A;
        this.B = B;
        this.C = C;
        this.v = v;
    }
    public tuple Pivot(int l, int e){
        float[] B_new = new float[m];
        float[][] A_new = new float[m][n];
        float[] C_new = new float[n];
        float v_new;
        B_new[l] = B[l]/A[l][e];
        for(int j = 0; j < n; j++){
            if(j == e)continue;
            A_new[l][j] = A[l][j]/A[l][e];
        }
        A_new[l][e] = 1 / A[l][e];
        for(int i = 0; i < m; i++){
            if(i == l)continue;
            B_new[i] = B[i] - A[i][e] * B_new[l];
            for(int j = 0; j < n; j++){
                if(j == e)continue;
                A_new[i][j] = A[i][j] - A[i][e] * A_new[l][j];
            }
            A_new[i][e] = -1 * A[i][e] * A_new[l][e];
        }
        v_new = v + C[e] * B_new[l];
        for(int j = 0; j < n; j++){
            if(j == e)continue;
            C_new[j] = C[j] - C[e] * A_new[l][j];
        }
        C_new[e] = -1 * C[e] * A_new[l][e];
        return new tuple(n, m, A_new, B_new, C_new, v_new);
    }
}
