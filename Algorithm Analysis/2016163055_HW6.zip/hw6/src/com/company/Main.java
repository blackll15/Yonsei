package com.company;

import java.io.*;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;
        try {
            fr = new FileReader("C:\\hw6\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw6\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                String output = "";
                s = br.readLine();
                String[] line = s.split(" ");
                int n = Integer.parseInt(line[0]);
                int m = Integer.parseInt(line[1]);
                s = br.readLine();
                line = s.split(" ");
                float[] C = new float[n];
                for(int j = 0; j < n; j++)C[j] = Float.parseFloat(line[j]);
                float V = 0;
                bw.write("#"+Integer.toString(i + 1));
                float[][] A = new float[m][n];
                float[] B = new float[m];
                for(int j = 0; j < m; j++){
                    s = br.readLine();
                    line = s.split(" ");
                    for(int k = 0; k < n; k++){
                        A[j][k] = Float.parseFloat(line[k]);
                    }
                    B[j] = Integer.parseInt(line[n]);
                }
                tuple T = new tuple(n, m, A, B, C, V);
                boolean optimal = true;
                boolean unbound = false;
                for(int j = 0; j < n; j++)if(C[j] > -0.0000001)optimal = false;
                while(!optimal){
                    //select pivot
                    int e = 0;
                    float bigcoeff = 0;
                    for(int j = 0; j < n; j++){
                        if(T.C[j] - bigcoeff > 0.00000001){
                            bigcoeff = T.C[j];
                            e = j;
                        }
                    }
                    boolean[] finitevalue = new boolean[m];
                    float lowestvalue = 0;
                    int idx = 0;
                    boolean inf = true;
                    for(int j = 0; j < m; j++){
                        if(T.A[j][e] > -0.00000001){
                            finitevalue[j] = true;
                            inf = false;
                            idx = j;
                            lowestvalue = T.B[j] / T.A[j][e];
                        }
                    }
                    if(inf){
                        unbound = true;
                        break;
                    }
                    for(int j = 0; j < m; j++){
                        if(finitevalue[j]){
                            if(lowestvalue - T.B[j] / T.A[j][e] > 0.000000001){
                                lowestvalue = T.B[j] / T.A[j][e];
                                idx = j;
                            }
                        }
                    }
                    T = T.Pivot(idx, e);
                    if(T.v - (int)T.v < 0.00000001)output += " " + Integer.toString((int)T.v);
                    else output += " " + String.format("%.2f", T.v);
                    optimal = true;
                    for(int j = 0; j < n; j++)if(T.C[j] > 0)optimal = false;
                }
                if(unbound) bw.write(" unbounded");
                else bw.write(output);
                bw.newLine();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}

