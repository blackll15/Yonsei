package com.company;

import java.io.*;

public class Main {

    public static int factorial(int n){
        if(n <= 1)return 1;
        return n*factorial(n - 1);
    }

    public static int combination(int n, int c){
        return factorial(n)/(factorial(c)*factorial(n - c));
    }

    public static int[] decompose(int s){
        String bst = Integer.toBinaryString(s);
        int bits = 0;
        int remainder = s;
        while(remainder > 0){
            bits += remainder % 2;
            remainder = remainder/2;
        }
        int[] res = new int[bits];
        int idx = 0;
        for(int i = 0; i < bst.length(); i++){
            if(bst.substring(bst.length() - i - 1, bst.length() - i).equals("1"))
                res[idx++] = i;
        }
        return res;
    }

    public static int nth_1_in_binary(int n , int i){
        for(int count = 0; i > 0; count++){
            if(i % 2 == 1)n--;
            if(n < 0)return count;
            i = i/2;
        }
        return 0;
    }

    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;
        try {
            fr = new FileReader("C:\\hw5\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw5\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                s = br.readLine();
                int n = Integer.parseInt(s);
                int[][] distance = new int[n][n];   //save distance between cities
                int[][] subsets = new int[n][];     //save n subset's bits
                int[] index = new int[n];           //index about subsets
                for(int j = 0; j < n; j++) {
                    index[j] = 0;
                    subsets[j] = new int[combination(n - 1, j)];
                }
                for(int j = 0; j < (int)Math.pow(2, n - 1); j++){
                    int bits = 0;
                    int remainder = j;
                    while(remainder > 0){
                        bits += remainder % 2;
                        remainder = remainder/2;
                    }
                    subsets[bits][index[bits]++] = j;
                }
                for(int j = 0; j < n; j++){
                    s = br.readLine();
                    String[] line = s.split(" ");
                    for(int k = 0; k < n; k++)distance[j][k] = Integer.parseInt(line[k]);
                }
                int[][] C = new int[(int)Math.pow(2,n - 1)][]; //C first index: set as a number , second index: destination j
                C[0] = new int[1];                                    // saves path distance
                C[0][0] = 0;
                for(int S = 1; S < n; S++){         //S is size of sets
                    for(int k = 0; k < subsets[S].length; k++){
                        int setnumber = subsets[S][k];
                        int[] setmember = decompose(setnumber);
                        C[setnumber] = new int[setmember.length + 1];
                        C[setnumber][0] = -1;
                        for(int j = 0; j < setmember.length; j++){
                            int min = 999999999;
                            int toindex = setnumber - (int)Math.pow(2, setmember[j]);
                            for(int t = 0; t < C[toindex].length; t++){
                                int dij;
                                if(t == 0)dij = distance[0][setmember[j] + 1];
                                else dij = distance[nth_1_in_binary(t - 1, toindex) + 1][setmember[j] + 1];
                                if(C[toindex][t] == -1 || dij == -1)continue;
                                else min = min > C[toindex][t] + dij ? C[toindex][t] + dij : min;
                            }
                            C[setnumber][j + 1] = min == 999999999 ? -1 : min;
                        }
                    }
                }
                int last = (int)Math.pow(2, n - 1) - 1;
                int min = 999999999;
                for(int j = 0; j < C[last].length; j++){
                    int dj0 = distance[0][j];
                    if(dj0 == -1 || C[last][j] == -1)continue;
                    else min = min > C[last][j] + dj0 ? C[last][j] + dj0: min;
                }
                bw.write("#" + Integer.toString(i + 1) + " " + Integer.toString(min));
                bw.newLine();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}

