package com.company;
import java.util.Arrays;
import java.util.Random;

public class func {
    public static UnionFind kruskal(int n, Edge[] edgearr){//kruskal's algorithm repeat n-2 times
        UnionFind U = new UnionFind(n);
        Edge[] X = new Edge[n-1];
        int xidx = 0;
        Arrays.sort(edgearr);
        int m = edgearr.length;
        for(int j = 0; j < m; j++){
            Edge e = edgearr[j];
            if(U.find(e.u) != U.find(e.v)){
                X[xidx++] = e;
                if(xidx == n-1)return U;// when there is only two sets
                U.union(e.u, e.v);
            }
        }
        return U;
    }
    public static int karger(int n, Edge[] edgearr){
        Random rand = new Random();
        for(int i = 0; i < edgearr.length; i++){
            edgearr[i].w = rand.nextInt();//give random weight
        }
        UnionFind U = kruskal(n, edgearr);
        int count = 0;//number of minimum cut
        for(int i = 0; i < edgearr.length; i++){
            Edge e = edgearr[i];
            if(U.find(e.u) != U.find(e.v))count++;
        }
        return count;
    }
    public static int dokarger(int n, Edge[] edgearr){// repeat karger's algorithm
        int k = (int)(n*(n-1)/2*Math.log(n))+1;
        int low = n;
        for(int i = 0; i < k; i++){
            int res = karger(n, edgearr);
            if (res < low)low = res;
        }
        return low;
    }
}
