package com.company;
import java.lang.Comparable;

public class Edge implements Comparable<Edge>{
    int u;
    int v;
    int w;
    public Edge(int u, int v, int w){
        this.u = u;
        this.v = v;
        this.w = w;
    }
    public int getWeight(){
        return w;
    }
    public int compareTo(Edge e){
        if(w > e.getWeight())return 1;
        else if(w < e.getWeight())return -1;
        return 0;
    }

}
