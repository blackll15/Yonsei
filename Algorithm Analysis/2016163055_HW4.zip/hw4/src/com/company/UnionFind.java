package com.company;

public class UnionFind {
    int size;
    int[] arr;
    int[] rank;
    public UnionFind(int s){
        size = s;
        arr = new int[s];
        rank = new int[s];
        for(int i = 0; i < s; i++){
            arr[i] = i;
            rank[i] = 0;
        }
    }
    public int find(int k){
        if(k == arr[k])return k;
        arr[k] = find(arr[k]);
        return find(arr[k]);
    }
    public void union(int u, int v){
        u = find(u);
        v = find(v);
        if(u == v)return;
        if(rank[u] > rank[v])arr[v] = u;
        else{
            arr[u] = v;
            if(rank[u] == rank[v])rank[v] += 1;
        }
    }

}
