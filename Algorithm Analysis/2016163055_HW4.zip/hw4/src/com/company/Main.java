package com.company;

import java.io.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            fr = new FileReader("C:\\hw4\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw4\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                s = br.readLine();
                String[] line = s.split(" ");

                int n = Integer.parseInt(line[0]);
                int m = Integer.parseInt(line[1]);
                UnionFind U = new UnionFind(n);
                Edge[] edgearr = new Edge[m];

                for(int j = 0; j < m; j++){// save all edges
                    s = br.readLine();
                    line = s.split(" ");
                    edgearr[j] = new Edge(Integer.parseInt(line[0]), Integer.parseInt(line[1]),0);
                }

                bw.write("#"+Integer.toString(i+1)+" "+Integer.toString(func.dokarger(n, edgearr)));//call karger's algorithm
                bw.newLine();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}
