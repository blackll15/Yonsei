package com.company;

import java.io.*;
import java.lang.Math;

public class Main {



    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            fr = new FileReader("C:\\hw3\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw3\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                s = br.readLine();
                String[] line = s.split(" ");
                int polysize = Integer.parseInt(line[0])+1;
                int exp = 0;
                for(int j = 0; j < 7; j++)
                    if(polysize > Math.pow(2,j))
                        exp = j;
                exp++;
                Complex[] input = new Complex[(int)Math.pow(2, exp)];
                Complex[] output = new Complex[(int)Math.pow(2, exp)];
                for(int j = 0; j < polysize; j++){
                    input[j] = new Complex(Integer.parseInt(line[j+1]),0);
                }
                for(int j = 0; j < (int)Math.pow(2, exp) - polysize; j++){
                    input[j + polysize] = new Complex(0,0);
                }
                new Complex(0,0).FFT(input, output);
                bw.write("#"+Integer.toString(i+1));
                bw.newLine();
                for(int j = 0; j < (int)Math.pow(2, exp); j++){
                    bw.write(new Complex(0,0).toString(output[j]));
                    bw.newLine();
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}
