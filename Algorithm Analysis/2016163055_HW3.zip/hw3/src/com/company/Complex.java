package com.company;

import java.lang.Math;

public class Complex {
    private double r;
    private double i;
    public Complex(double r, double i){
        this.r = r;
        this.i = i;
    }
    public double getI(){
        return i;
    }
    public double getR(){
        return r;
    }
    public Complex addC(Complex c1, Complex c2){
        return new Complex(c1.r+c2.r,c1.i+c2.i);
    }

    public Complex subC(Complex c1, Complex c2){
        return new Complex(c1.r-c2.r,c1.i-c2.i);
    }
    public Complex multC(Complex c1, Complex c2){
        return new Complex(c1.r*c2.r - c1.i*c2.i, c1.r*c2.i + c1.i*c2.r);
    }
    public String toString(Complex c){
        return String.format("%.6f",c.r) + " " + String.format("%.6f",c.i);
    }
    public void FFT(Complex[] A1, Complex[] A2){//A1 is original polynomial A2 is DFM
        int n = A1.length;
        if(n == 1){
            A2[0] = A1[0];
            return;
        }
        final double pi = 3.1415926535;
        Complex w = new Complex(Math.cos(-2.0 * pi / n), Math.sin(-2.0 * pi / n));
        Complex k = new Complex(1,0);
        Complex[] Ae1 = new Complex[n/2];
        Complex[] Ae2 = new Complex[n/2];
        Complex[] Ao1 = new Complex[n/2];
        Complex[] Ao2 = new Complex[n/2];
        for(int i = 0; i < n/2; i++){
            Ae1[i] = A1[2 * i];
            Ao1[i] = A1[2 * i + 1];
        }
        FFT(Ae1, Ae2);
        FFT(Ao1, Ao2);
        for(int i = 0; i < n ; i++){
            A2[i] = addC(Ae2[i%(n/2)], multC(k , Ao2[i%(n/2)]));
            k = multC(k, w);
        }
    }

}

