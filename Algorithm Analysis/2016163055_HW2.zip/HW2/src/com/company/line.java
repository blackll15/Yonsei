package com.company;

import java.util.LinkedList;

public class line {
    LinkedList<coord> points = new LinkedList<coord>();
    coord p1;
    coord p2;
    boolean slopeiszero = false;
    boolean infiniteslope = false;
    public line(coord i, coord j){
        points.add(i);
        points.add(j);
        p1 = i;
        p2 = j;
        if(p1.x == p2.x)infiniteslope = true;
        if(p1.y == p2.y)slopeiszero = true;
    }
    public boolean same(line i, line j){
        if(i.slopeiszero || j.slopeiszero){
            if(i.slopeiszero && j.slopeiszero && i.p1.y == j.p1.y)return true;
            else return false;
        }
        if(i.infiniteslope || j.infiniteslope){
            if(i.infiniteslope && j.infiniteslope && i.p1.x == j.p1.x)return true;
            else return false;
        }
        return (i.p1.x-i.p2.x)*(j.p1.y-j.p2.y) == (j.p1.x - j.p2.x)*(i.p1.y-i.p2.y)
                && (i.p1.x-i.p2.x)*i.p1.x - (i.p1.y-i.p2.y)*i.p1.y
                == (j.p1.x - j.p2.x)*j.p1.x - (j.p1.y-j.p2.y)*j.p1.y;
    }
    public float slope(){
        if(infiniteslope)return 999999;
        else if(slopeiszero)return 0;
        return (float)(p1.x-p2.x)/(float) (p1.y-p2.y);
    }
}
