package com.company;

public class coord {
    int x;
    int y;
    public coord(int x, int y){
        this.x = x;
        this.y = y;
    }
}
