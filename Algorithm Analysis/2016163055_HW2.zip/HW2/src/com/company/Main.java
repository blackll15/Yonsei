package com.company;

import java.io.*;
import java.util.Iterator;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            fr = new FileReader("C:\\hw2\\input.txt");
            br = new BufferedReader(fr);
            fw = new FileWriter("C:\\hw2\\2016163055.txt",false);
            bw = new BufferedWriter(fw);
            String s = null;
            s = br.readLine();
            int testcase = Integer.parseInt(s);
            for(int i = 0; i < testcase; i++){
                s = br.readLine();
                s = br.readLine();
                int coordnum = Integer.parseInt(s);
                coord[] coordarr = new coord[coordnum];
                LinkedList<line> linelist = new LinkedList<line>();
                LinkedList<coord> pointinline3 = new LinkedList<coord>();
                LinkedList<coord> intersectionP = new LinkedList<coord>();

                for(int j = 0; j < coordnum; j++){
                    s= br.readLine();
                    String[] line = s.split(" ");
                    int x = Integer.parseInt(line[0]);
                    int y = Integer.parseInt(line[1]);
                    coordarr[j] = new coord(x,y);
                    for(int k = 0; k < j; k++) {
                        line tmpline = new line(coordarr[j], coordarr[k]);
                        boolean flag = false;
                        for (Iterator<line> iter = linelist.iterator(); iter.hasNext(); ) {
                            line cur = (line) iter.next();
                            if (cur.same(cur, tmpline)){
                                if(!cur.points.contains(coordarr[j]))cur.points.add(coordarr[j]);
                                flag = true;
                                break;
                            }
                        }
                        if(!flag)linelist.add(tmpline);
                    }
                }
                for(Iterator<line> iter = linelist.iterator(); iter.hasNext();){
                    line cur = (line) iter.next();
                    System.out.println(cur.slope());
                    if(cur.points.size() > 2){
                        for(Iterator<coord> iter2 = cur.points.iterator(); iter2.hasNext();){
                            coord cur2 = (coord)iter2.next();
                            if(pointinline3.contains(cur2)){
                                if(!intersectionP.contains(cur2))intersectionP.add(cur2);
                            }
                            else pointinline3.add((cur2));
                        }
                    }
                }
                bw.write(Integer.toString(intersectionP.size()));
                bw.newLine();
                for(Iterator<coord> iter = intersectionP.iterator();iter.hasNext();){
                    coord cur = (coord)iter.next();
                    bw.write(cur.x+" "+cur.y);
                    bw.newLine();
                }
                bw.newLine();

            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(br != null) try{br.close();}catch(IOException e){}
            if(fr != null) try{fr.close();}catch(IOException e){}
            if(bw != null) try{bw.close();}catch(IOException e){}
            if(fw != null) try{fw.close();}catch(IOException e){}
        }
    }
}

