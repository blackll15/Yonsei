def removeValuesInPlace(L, threshold):
    # Your code here (provide your own comments, please):
    removed = 0#number of removed elements
    for n in range(len(L)):
        if(L[n-removed] > threshold):
            del L[n-removed]
            removed += 1
    return L
