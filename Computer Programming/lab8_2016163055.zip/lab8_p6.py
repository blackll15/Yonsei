import turtle

def drawSquare(myturtle, x, y, a):
    myturtle.penup()
    myturtle.setposition(x, y)
    myturtle.pendown()
    myturtle.setposition(x + a, y)
    myturtle.setposition(x + a, y + a)
    myturtle.setposition(x, y + a)
    myturtle.setposition(x, y)