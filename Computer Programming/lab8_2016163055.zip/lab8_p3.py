def resetValues(L, threshold):
    Result = []
    # Your code to compute "Result"here:
    for n in range(len(L)):#append L to Result
        if(L[n] > threshold):
            Result.append(0)
        else:
            Result.append(L[n])
    return Result