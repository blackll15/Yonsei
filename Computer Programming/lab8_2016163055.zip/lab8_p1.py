def resetValuesInPlace(L, threshold):
    #Your code here (provide your own comments, please):
    for n in range(len(L)):
        L[n] = 0 if L[n] > threshold else L[n]# if L[n] is bigger than threshold, change to 0
    return L
