i = int(input("Enter the taxable income in USD: "))
if(i > 7000):
    t = 230.0 + (i - 7000)*0.06
elif(i > 5250):
    t = 142.50 + (i - 5250)*0.05
elif(i > 3750):
    t = 82.50 + (i - 3750)*0.04
elif(i > 2250):
    t = 37.50 + (i - 2250)*0.03
elif(i > 750):
    t = 7.50 + (i - 750)*0.02
elif(i > 0):
    t = i*0.01
print("Tax due: %.2f USD"%t)
