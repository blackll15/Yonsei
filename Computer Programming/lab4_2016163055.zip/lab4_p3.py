s1 = input("Enter a number: ")
if(len(s1) == 1):
    s2 = "digit"
else:
    s2 = "digits"
print("The number",s1,"contains",str(len(s1)),s2)