for i in range(1,101):
    print("%3d"%i,end="")
    if(i%10 == 0):print()