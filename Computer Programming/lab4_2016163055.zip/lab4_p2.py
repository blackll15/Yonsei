sum = 0
b = int(input("Your number: "))
while(b != 0):
    if(b <= 100):
        sum += b
    b = int(input("Your number: "))
print("Sum:",sum)
