Lab 3 answers by Kim Seongwoo, student ID 2016163055

Q1: (((var1 * 8) - var2) + (32 / var3))

Q2: (a) var1 *(1) var2 *(2) var3 -(3) var4
      (b) var1 *(1) var2 /(2) var3
      (c) var1 **(2) var2 **(1) var3

Q3: a

Q4: (a) 24 not in nums
      (b) 'Ellen' in names
      (c) last_name == 'Morris' or last_name == 'Morrison'

Q5: print("John Doe\n123 Main Street\nAnytown, Maryland 21009")

Q6: print("It\'s raining today.")

Q7: (a) 2.0 
      (b) 2
      (c) 2.0
