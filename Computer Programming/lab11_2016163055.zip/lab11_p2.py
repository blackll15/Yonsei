import time

SIZE=20 # size of the 2D cellular automaton
max_generation = 0
work = []
tmp  = []
surrounding = ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1))

def printSep():
    '''Print a separator'''
    for ctr in range(0, SIZE+2):
        print('-', end='')
    print('')


def printWorld(world):
    '''Print one generation.
       Must use printSep() above to print the separators.
    '''
    printSep()
    for i in range(SIZE):
        line = '|'
        for j in range(SIZE):
            if(world[i][j] == 0 ): line += ' '
            else: line += 'x'
        line += '| row ' + str(i)
        print(line)
    printSep()

def changeWorld(world):
    '''
    :param world
    :return: tmp
    '''
    tmp = []
    for i in range(SIZE):
        tmp.append([0] * SIZE)
    for i in range(SIZE):
        for j in range(SIZE):
            live_or_dead(world, tmp, i, j)
    return tmp
def live_or_dead(world, tmp, x, y):
    '''
    :param world
    :return: void
    '''
    count = 0
    for i in range(8):
        pos = (x + surrounding[i][0], y + surrounding[i][1])
        if(pos[0] >= SIZE or pos[0] < 0 or pos[1] >= SIZE or pos[1] < 0): continue
        if(world[pos[0]][pos[1]] == 1):count += 1
    if(world[x][y] == 1):
        if(count == 2 or count == 3): tmp[x][y] = 1
        else: tmp[x][y] = 0
    else:
        if(count == 3): tmp[x][y] = 1
        else: tmp[x][y] = 0

#
# Main program
#

# Initialize work and tmp:
try :
    SIZE = int(input('Grid sidelength (default 20): '))
    if(SIZE < 20): SIZE = 20
except:
    SIZE = 20
while(max_generation <= 0):
    try:
        max_generation = int(input('Max generation: '))
    except:
        continue
for i in range(SIZE):
    work.append([0]*SIZE)
work[0][1] = 1;
work[1][1] = 1;
work[2][1] = 1;
work[10][10] = 1;
work[10][11] = 1;
work[10][12] = 1;
work[11][10] = 1;
work[12][10] = 1;
work[12][11] = 1;
work[12][12] = 1;

# Compute:
while max_generation + 1:
    printWorld(work)
    work = changeWorld(work)
    time.sleep(1)
    max_generation -= 1
