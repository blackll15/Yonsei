def copyFiles(f1, f2, f3):
    """ Copies f1 and f2 onto f3.
    The function assumes that files f1 and f2 can be opened, and that
    no error occurs in writing file f3.
    """
    try:
        file1 = open(f1)
        file2 = open(f2)
        file3 = open(f3,'w')
        for line in file1:
            file3.write(line)
            file3.newlines
        for line in file2:
            file3.write(line)
            file3.newlines
        file1.close()
        file2.close()
        file3.close()
        return 0
    except:
        return -1
