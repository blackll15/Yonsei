b = int(input("What base? "))
n = int(input("what power of {}? ".format(b)))
print(str(b)+" to the power of "+ str(n) +" is {}".format(b**n))