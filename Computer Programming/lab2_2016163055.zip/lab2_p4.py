a = int(input("Number1: "))
b = 0
while(b == 0):
    b = int(input("Number2: "))
print("Result: %.2f"%(float(a)/float(b)))
