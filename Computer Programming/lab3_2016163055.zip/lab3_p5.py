p1m = int(input("Person 1: Enter month born (1-12): "))
p1d = int(input("Person 1: Enter day born (1-31): "))
p1y = int(input("Person 1: Enter year born (4-digit): "))
p2m = int(input("Person 1: Enter month born (1-12): "))
p2d = int(input("Person 1: Enter day born (1-31): "))
p2y = int(input("Person 1: Enter year born (4-digit): "))
numsecs_day = 24 * 60 * 60
numsecs_year = 365 * numsecs_day
avg_numsecs_year = ((4 * numsecs_year) + numsecs_day) // 4
avg_numsecs_month = avg_numsecs_year // 12
p1t = p1y*avg_numsecs_year + p1m * avg_numsecs_month + p1d * numsecs_day
p2t = p2y*avg_numsecs_year + p2m * avg_numsecs_month + p2d * numsecs_day
print("Age difference in seconds: " + str(abs(p1t - p2t)))
