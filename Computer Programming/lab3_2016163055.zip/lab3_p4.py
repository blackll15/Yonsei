import random
a = random.randint(1,45)
b = random.randint(1,45)
c = random.randint(1,45)
d = random.randint(1,45)
e = random.randint(1,45)
f = random.randint(1,45)
print('Lotto numbers of the week: '+ str(a)+' ' + str(b)+' '+ str(c)+' '+ str(d)+' '+ str(e)+' '+ str(f))