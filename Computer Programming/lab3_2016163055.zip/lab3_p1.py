import math

i = int(input("Enter USB size (GB): "))
print('%5d images in GIF format can be stored'%math.floor(float(i*(10**9))/float(800*600*1/5)))
print('%5d images in JPEG format can be stored'%math.floor(float(i*(10**9))/float(800*600*3/25)))
print('%5d images in PNG format can be stored'%math.floor(float(i*(10**9))/float(800*600*3/8)))
print('%5d images in TIFF format can be stored'%math.floor(float(i*(10**9))/float(800*600*6)))
