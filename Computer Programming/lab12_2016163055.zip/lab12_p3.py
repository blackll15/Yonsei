import random;
filename = input('Enter a filename: ')
try:
    file = open(filename)
    filename = filename.split('.')
    if(filename[1] == 'txt'):
        keyfile = open(filename[0] + '.key','w')
        encryptfile = open(filename[0] + '.enc', 'w')
        key = random.randrange(1,7)
        keyfile.write(str(key))
        for line in file:
            hasEnter = '\n' in line
            line = line.strip('\n')
            newline = ''
            for ch in line:
                newline += chr(ord(ch) + key)
            if(hasEnter): newline += '\n'
            encryptfile.write(newline)
        encryptfile.close()
        keyfile.close()
    elif(filename[1] == 'enc'):
        keyfile = open(filename[0] + '.key')
        decryptfile = open(filename[0] + '.txt', 'w')
        key = int(keyfile.readline())
        for line in file:
            hasEnter = '\n' in line
            line = line.strip('\n')
            newline = ''
            for ch in line:
                newline += chr(ord(ch) - key)
            if (hasEnter): newline += '\n'
            decryptfile.write(newline)
        decryptfile.close()
        keyfile.close()
    file.close()
except:
    print('Error!')
