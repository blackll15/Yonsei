def moderateDays(mydict):
    '''Returns a list [...] of the days for which the average
    temperature was between 70 and 79 degrees.
    '''
    res = list();
    for days in mydict.keys():
        if(mydict[days] < 80 and mydict[days] >= 70): res.append(days)
    return res