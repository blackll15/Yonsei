def evalPolynomial(x):
    return ((((3 * x + 2) * x - 5) * x -1) * x + 7) * x - 6
x = int(input('Enter a value for x: '))
print('Polynomial for x='+str(x)+':',str(evalPolynomial(x)))
