Lab 7 answers by Kim Seongwoo, student ID 2016163055

Q1: (b), (c), (d), (e)

Q2: (a), (d)

Q3: True