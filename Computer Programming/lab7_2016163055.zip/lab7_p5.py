S = input('Enter an ISBN: ')
sl = ['GS1 prefix', 'Group identifier', 'Publisher code', 'Item number', 'Check digit']
for i in range(5):
    print(format(S.split('-')[i],'.<20s')+sl[i])