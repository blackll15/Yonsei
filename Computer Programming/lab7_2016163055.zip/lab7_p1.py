def zeroCheck(a, b, c):
    return a == 0 or b == 0 or c == 0