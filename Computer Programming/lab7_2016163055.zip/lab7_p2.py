def ordered3(a, b, c):
    return a <= b and b <= c