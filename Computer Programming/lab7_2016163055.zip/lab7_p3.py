def modCount(n, m):
    if(m > n): return
    return n//m