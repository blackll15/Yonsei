f = float(input('Enter a number: '))
big = f
if(f <= 0 ):
    print('No positive number was entered')
else:
    while(f > 0):
        f = float(input('Enter a number: '))
        if(big < f):
            big = f
    print('The largest number entered was','{:.2f}'.format(big))