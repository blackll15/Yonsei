s = input("Enter a sentence: ")
l = {"A","a","E","e","I","i","O","o","U","u"}
result = 0
for vol in l:
    result += s.count(vol)
print("Your sentence contains",result,"vowels.")