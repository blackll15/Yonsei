n = int(input("Enter an integer: "))
l = list()
while(n != 0):
    if(n > 100):
        l.append('over')
    else:
        l.append(n)
    n = int(input("Enter an integer: "))
print(l)