n = int(input('Enter an integer: '))
for k in range(n):
    print(" " * k + "*" * (2 * (n - k) - 1) + " " * k)
