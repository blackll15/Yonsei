name = input("Enter a name (q to quit): ")
l = list()
l.append(name)
while(name != "q"):
    name = input("Enter a name (q to quit): ")
    l.append(name)
result = 0
for n in l:
    result += n.count("a")
    result += n.count("A")
print("Appearance of letter 'a':",result)