import stack
str = input('Enter parentheses and/or braces: ')
proper = True
s = stack.getStack()
for ch in str:
    if(ch == '{' or ch == '('):
        stack.push(s, ch)
    elif(ch == '}'):
        if(stack.top(s) != '{'):
            proper = False
            break
        stack.pop(s)
    else:
        if(stack.top(s) != '('):
            proper = False
            break
        stack.pop(s)
if(proper and stack.isEmpty(s)):
    print('Nested properly.')
else:
    print('Not properly nested.')