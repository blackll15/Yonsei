def drawFlower(myturtle, r):
    """ Draws a flower composed of 24 circles
        on the screen. The radius of the
        circles is ``r''.
        The drawing color is ``red''.
        The turtle ``myturtle'' is already
        positioned in the center of the flower.
    """
    # Your code here:
    pi = 3.141592
    import math
    myturtle.pencolor('red')
    myturtle.hideturtle()
    pos = myturtle.position()
    def drawcircle(myturtle, r, x, y):
        myturtle.penup()
        myturtle.setposition(x + r, y)
        myturtle.pendown()
        for n in range(361):
            myturtle.setposition(x + r * math.cos(pi * n / 180), y + r * math.sin(pi * n / 180))
        myturtle.penup()
    for k in range(24):
        drawcircle(myturtle, r/2, pos[0] + r/2 * math.cos(pi * k / 12), pos[1] + r/2 * math.sin(pi * k / 12))


# Nothing else.