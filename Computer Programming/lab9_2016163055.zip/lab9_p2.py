from stack import *

str = input('Enter an RPN expression: ')
while(str != 'q'):
    s = getStack()
    str = str.split(' ')
    for n in range(len(str)):
        if(str[n] == '+'):
            push(s, pop(s) + pop(s))
        elif(str[n] == '-'):
                push(s, - pop(s) + pop(s))
        elif(str[n] == '*'):
            push(s, pop(s) * pop(s))
        elif(str[n] == '/'):
            push(s, 1 / pop(s) * pop(s))
        elif(str[n] == '='):
            x = pop(s)
            if(abs(x - int(x)) < 0.000000001):
                print('Value of expression:', int(x))
            else:
                print('Value of expression:', '[{0:0.2f}]'.format(x))
        else:
            push(s, int(str[n]))
    str = input('Enter an RPN expression: ')
