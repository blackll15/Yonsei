import math
def gcd(a, b):
    if(b == 0):
        return a;
    return gcd(b, a%b)
s = input("Enter a fraction: ")
slash = False
nom = ""
denom = ""
for c in s:
    if(c == '/'):
        slash = True
        continue
    if(c != ' '):
        if(slash):
            denom += c
        else:
            nom += c
n = gcd(int(nom),int(denom))
print("In lowest terms:", str(int(int(nom) / n)),end="")
if(int(int(denom) / n) != 1):
    print("/" + str(int(int(denom) / n)))
else:
    print()

