import operator
l = list()
s = input("Enter a fruit type (q to quit): ")

while(s != "q"):
    m = int(input("Enter the weight in kg: "))
    hasItem = False
    for ele in l:
        if(ele[0] == s):
            ele[1] += m
            hasItem = True
    if(not hasItem):
        l.append([s, m])
    s = input("Enter a fruit type (q to quit): ")
l.sort(key = operator.itemgetter(0))
for ele in l:
    print(ele[0]+",", str(ele[1]))
