l = list()
s = input("Enter a word (q to quit): ")
while(s != "q"):
    if(s[0].upper() in s[1:].upper()):
        l.append(s)
    s = input("Enter a word (q to quit): ")
l.sort()
print(l)
