s = input("Enter a first and last name: ")
print(s.split()[1]+",", s.split()[0][0]+".")