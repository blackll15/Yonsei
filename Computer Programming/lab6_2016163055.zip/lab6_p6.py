l = int(input("Enter the limit L: "))
while(l != 0):
    sum = 0
    for i in range(1, l+1):
        sum += 1/float(i)
    print("Sum of the initial",l,"term(s): %.6f"%sum)
    l = int(input("Enter the limit L: "))
