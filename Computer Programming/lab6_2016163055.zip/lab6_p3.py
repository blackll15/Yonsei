import sys
# Password Encryption/Decryption Program

# init
password_out = ''
alphalist = list(range(97,123)) + list(range(65,91))
numlist = list(range(48,58))
specialist = [35] + [37] + [64]
hasalpha = False
hasnum = False
hasspecial = False
valid = alphalist + numlist + specialist
case_changer = ord('a') - ord('A')
encryption_key = (('a', 'm'), ('b', 'h'), ('c', 't'), ('d', 'f'), ('e', 'g'), ('#', '!'), ('@', '('), ('%', ')'),
                  ('f', 'k'), ('g', 'b'), ('h', 'p'), ('i', 'j'), ('j', 'w'), ('k', 'e'), ('l', 'r'),
                  ('m', 'q'), ('n', 's'), ('o', 'l'), ('p', 'n'), ('q', 'i'), ('r', 'u'), ('s', 'o'),
                  ('t', 'x'), ('u', 'z'), ('v', 'y'), ('w', 'v'), ('x', 'd'), ('y', 'c'), ('z', 'a'))

encrypting = True
invalid = False
# get password
password_in = input('Enter password: ')
for c in password_in :
    if(ord(c) in alphalist):
        hasalpha = True
    elif(ord(c) in numlist):
        hasnum = True
    elif(ord(c) in specialist):
        hasspecial = True
    else:
        invalid = True
invalid = not(not invalid and hasnum and hasspecial and hasalpha)
if(invalid):
    print("Invalid password!")
    sys.exit()
# perform encryption / decryption
if encrypting:
    from_index = 0
    to_index = 1
else:
    from_index = 1
    to_index = 0

case_changer = ord('a') - ord('A')

for ch in password_in:
    letter_found = False

    for t in encryption_key:
        if (ord(ch) in list(range(97,123))+[35]+[37]+[64]) and ch == t[from_index]:
            password_out = password_out + t[to_index]
            letter_found = True
        elif ('A' <= ch and ch <= 'Z') and chr(ord(ch) + 32) == t[from_index]:
            password_out = password_out + chr(ord(t[to_index]) - case_changer)
            letter_found = True

    if not letter_found:
        password_out = password_out + ch

# output
if encrypting:
    print('Your encrypted password is:', password_out)
else:
    print('Your decrypted password is:', password_out)
