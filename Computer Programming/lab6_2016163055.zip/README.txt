Lab 6 answers by Kim Seongwoo, student ID 2016163055

Q1: (a) print(str1[3])
      (b) print(str1.index("o"))

Q2: (a) print(len(lst))
      (b) print(len(lst)*3)
      (c)
sum = 0
for l in lst:
    for ele in l:
        sum += ele
print(sum)
       (d) lst[3][2] = 12
Q3: (a) 10, 50
      (b) 50, 50
      (c) 15, 15
      (d) 0, 0