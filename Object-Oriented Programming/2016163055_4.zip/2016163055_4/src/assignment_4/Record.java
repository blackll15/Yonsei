package assignment_4;

import java.lang.Runnable;

public class Record implements Runnable{
	BallLabel balllabel;
	public Record(BallLabel L) {
		this.balllabel = L;
	}
	public void run(){
		while(true) {
			try{
				System.out.println("up : " + balllabel.up +
						" / down : " + balllabel.down +
						" / right : " + balllabel.right +
						" / left : " + balllabel.left);
				Thread.sleep(3000);
			}
			catch(InterruptedException e) {
				return;
			}
		}
	}
}

