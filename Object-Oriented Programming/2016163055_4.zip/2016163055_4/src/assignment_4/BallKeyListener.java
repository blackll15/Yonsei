package assignment_4;

import java.awt.event.*;


public class BallKeyListener extends KeyAdapter{
	BallThread th;
	BallKeyListener(BallThread th){
		this.th = th;
	}
	public void keyPressed(KeyEvent e) {
		
		int keycode = e.getKeyCode();
		
		switch(keycode){
			case KeyEvent.VK_UP ://speed up
				if(th.speed > 0)th.speed -= 40;//speed is 0 at minimum
				break;
			case KeyEvent.VK_DOWN ://speed down
				if(th.speed <1000)th.speed += 40;//speed is 1000at maximum
				break;
			case KeyEvent.VK_R : //redirect
				th.balllabel.directX = -1+2*((int)Math.round(Math.random()));
				th.balllabel.directY = -1+2*((int)Math.round(Math.random()));
		}
	}
}


