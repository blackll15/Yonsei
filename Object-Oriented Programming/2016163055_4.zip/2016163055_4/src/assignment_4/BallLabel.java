package assignment_4;

import java.awt.*;
import javax.swing.*;
import java.lang.Math;

public class BallLabel extends JLabel{
	int directX = -1+2*((int)Math.round(Math.random()));
	int directY = -1+2*((int)Math.round(Math.random()));
	int posX = 5*((int)Math.round(Math.random()*54));
	int posY = -5+5*((int)Math.round(Math.random()*52));
	int up = 0;
	int down = 0;
	int left = 0;
	int right = 0;
	
	
	public BallLabel() {
		this.setText("@");
		this.setForeground(Color.blue);
		setSize(15,15);
		setVisible(true);
	}
	public void Move() {
		posX += 5*directX;
		posY += 5*directY;
		if(posX == -5 || posX == 275) {//new position is at edge
			if(posX == -5) left += 1;
			else right += 1;
			directX *= -1;//redirect
			posX += 10*directX;//bounce off
		}
		if(posY == -10 || posY == 250) {
			if(posY == -10) up += 1;
			else down += 1;
			directY *= -1;
			posY += 10*directY;
		}
		setLocation(posX,posY);
	}

}
