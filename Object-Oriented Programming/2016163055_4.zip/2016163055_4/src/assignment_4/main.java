package assignment_4;

public class main {

	public static void main(String[] args) {
		
		new GamePanel("2016163055");//title

	}

}
