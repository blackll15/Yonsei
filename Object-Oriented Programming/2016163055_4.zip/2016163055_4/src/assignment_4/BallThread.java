package assignment_4;

import java.lang.Runnable;


public class BallThread implements Runnable{
	BallLabel balllabel;
	int speed;
	public BallThread(BallLabel L) {
		this.balllabel = L;
		speed = 200;
	}
	public void run() {
		while(true) {
			try {
				Thread.sleep(speed);
				balllabel.Move();
			}
			catch(InterruptedException e) {
				return;
			}
		}
	}

}
