package assignment_4;

import javax.swing.*;

public class GamePanel extends JFrame {
	JPanel contentPane = new JPanel();
	BallLabel L = new BallLabel();
	
	GamePanel(String title){
		setTitle(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setContentPane(contentPane);
		
		BallThread runnable = new BallThread(L);
		Record runnable2 = new Record(L);
		Thread th = new Thread(runnable);
		Thread th2 = new Thread(runnable2);
		
		contentPane.addKeyListener(new BallKeyListener(runnable));
		contentPane.add(L);
		
		setBounds(100,100,300,300);
		setVisible(true);
		contentPane.requestFocus();
		
		th.start();
		th2.start();
	}
	

}
