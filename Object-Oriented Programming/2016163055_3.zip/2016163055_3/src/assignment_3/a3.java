package assignment_3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.text.DecimalFormat;
public class a3 {
	public static class Gpoint{//class storing location
		double x;
		double y;
	}	
	
	public static class SiteInfo{//class storing point information
		String name;
		Gpoint pt = new Gpoint();
		public SiteInfo(String name, double x, double y) {
			this.name = name;
			pt.x = x;
			pt.y = y;
		}
	}
	/**
	 * get weight of given location
	 * @param row 
	 * @param col
	 * @return weight
	 */
	public static double getWeight(int row, int col) {
		if (col < 0|| row < col)return 0;
		return 1+getWeight(row-1,col-1)/2+getWeight(row-1,col)/2;
	}
	/**
	 * get distance between two points
	 * @param a point 1
	 * @param b point 2
	 * @return distance
	 */
	public static double route(SiteInfo a,SiteInfo b) {
		return Math.pow(Math.pow(a.pt.x-b.pt.x,2)+Math.pow(a.pt.y-b.pt.y,2),0.5);
	}
	/**
	 * get length of given path
	 * @param path
	 * @return path length
	 */
	public static double RouteLength(ArrayList<SiteInfo> path) {
		double dis = 0;
		for(int i = 0; i < path.size()-1; i++) {
			dis += route(path.get(i),path.get(i+1));
		}
		return dis;
	}
	/**
	 * concatenate three SiteInfo
	 * @param a1
	 * @param a2
	 * @param a3
	 * @return concatenated siteInfo array
	 */
	public static ArrayList<SiteInfo> concat(SiteInfo a1, ArrayList<SiteInfo> a2, SiteInfo a3){
		ArrayList<SiteInfo> res = new ArrayList<SiteInfo>();
		res.add(a1);
		res.addAll(a2);
		res.add(a3);
		return res;
	}
	/**
	 * recursive function that finds shortest path which visits every sites once for given SiteInfo array
	 * first and last SiteInfo is conserved only nodes between them changes position
	 * @param sites
	 * @return shortest path
	 */
	public static ArrayList<SiteInfo> shortest_path(ArrayList<SiteInfo> sites){
		if (sites.size() < 4) return sites;
		ArrayList<SiteInfo> newsite = new ArrayList<SiteInfo>();
		ArrayList<SiteInfo> shortest_path = new ArrayList<SiteInfo>();
		shortest_path.addAll(sites);
		double shortestlength = RouteLength(sites);
		SiteInfo firstsite,endsite;
		firstsite = sites.get(0);
		endsite = sites.get(sites.size()-1);
		for(int i = 1;i < sites.size()-1;i++) {//insert node except first and last node of sites to newsite 
			newsite.add(sites.get(i));
		}
		for(int i = 0;i < newsite.size()-1;i++) {//change position of second node of sites
			SiteInfo front = newsite.get(i);
			newsite.remove(i);
			newsite.add(0,front);
			for(int j = i; j < newsite.size()-1;j++) {//size-1 ,size-2,....0 times change position
				SiteInfo front1 = newsite.get(i+1);//change position i+1th node and end
				newsite.remove(i+1);
				newsite.add(front1);//change position i+1th node and end
				ArrayList<SiteInfo> tmp,tmp1 = new ArrayList<SiteInfo>();
				tmp1 = shortest_path(newsite);//recursively call function
				for(int k = 0;k<2;k++) {
					if(k == 0) {
						tmp = concat(firstsite,tmp1,endsite);
						if (RouteLength(tmp)<shortestlength) {//if length is short, change shortest path
							shortest_path.clear();
							shortest_path.addAll(tmp);
							shortestlength = RouteLength(tmp);
						}
					}
					if(k == 1) {
						tmp = concat(endsite,tmp1,firstsite);
						if (RouteLength(tmp)<shortestlength) {
							shortest_path.clear();
							shortest_path.addAll(tmp);
							shortestlength = RouteLength(tmp);
						}
					}
				}
			}
		}
		return shortest_path;
	}
	/**
	 * method that finds shortest path that ends at starting point 
	 * @param sites
	 * @return shortest loop path
	 */
	public static ArrayList<SiteInfo> bestRouteFor(ArrayList<SiteInfo> sites){
		if (sites.size() < 3) return sites;
		double shortestlength =0;
		ArrayList<SiteInfo> shortestsite = new ArrayList<SiteInfo>();
		for(int i = 0; i < sites.size(); i++) {//test all points as starting point
			SiteInfo starting_point = sites.get(i);
			ArrayList<SiteInfo> tmp = new ArrayList<SiteInfo>();
			tmp.addAll(sites);
			tmp.remove(i);
			tmp.add(0, starting_point);;
			tmp.add(starting_point);
			tmp = shortest_path(tmp);
			if(i == 0 || RouteLength(tmp) < shortestlength) {//if length is low, change shortest path
				shortestsite.clear();
				shortestsite.addAll(tmp);
				shortestlength = RouteLength(tmp);
			}
		}	
		shortestsite.remove(shortestsite.size()-1);
		return shortestsite;
	}
	
	public static void main(String[] args) {
		FileReader fr = null;
		FileWriter fw = null;	
		BufferedReader br = null;
		BufferedWriter bw = null;
		
		try {
			fr = new FileReader("input.txt");
			br = new BufferedReader(fr);
			fw = new FileWriter("output.txt",false);
			bw = new BufferedWriter(fw);
		String s = null;
		s = br.readLine();
		s = br.readLine();
		double w = Double.parseDouble(s);
		s = br.readLine();
		ArrayList<SiteInfo> sites = new ArrayList<SiteInfo>();
		while(!(s = br.readLine()).equals("")){
			String s1 = s.substring(0, 1);
			String s2 = s.substring(3, s.length()-1);
			String[] s2arr = s2.split("\\)");
			s2arr = s2arr[0].split(", ");
			sites.add(new SiteInfo(s1,Double.parseDouble(s2arr[0]),Double.parseDouble(s2arr[1])));
		}
		sites = bestRouteFor(sites);
		sites.add(sites.size(), sites.get(0));
		bw.write("route : ");
		for(int i = 0;i < sites.size()-1;i++)bw.write(sites.get(i).name);
		bw.newLine();
		DecimalFormat form = new DecimalFormat("#.###");
		bw.write("length : "+form.format(RouteLength(sites)));
		bw.newLine();
		bw.newLine();
		s = br.readLine();
		while((s = br.readLine()) != null){
			String[] strarr = s.split(",");
			int x = Integer.parseInt(strarr[0]);
			int y = Integer.parseInt(strarr[1]);
			bw.write(Double.toString(w*getWeight(x,y)));
			bw.newLine();	
		}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(br != null) try{br.close();}catch(IOException e){}
			if(fr != null) try{fr.close();}catch(IOException e){}
			if(bw != null) try{bw.close();}catch(IOException e){}
			if(fw != null) try{fw.close();}catch(IOException e){}
		}
	}
}
