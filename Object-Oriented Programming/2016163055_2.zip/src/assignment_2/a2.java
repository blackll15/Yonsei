package assignment_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;


public class a2 {
	public static class worker{//worker class
		public double won;
		public double incentive;
		public worker(double won, double incentive){
			this.won = won;
			this.incentive = incentive;
		}
		public int pay(double n1, double n2) {//calculate money for Parttime worker
			return (int)((n1+(n2*(incentive-1)))*won);
		}
	}
	
	public static class Parttime extends worker{
		public Parttime(double won , double incentive ) {
			super(won, incentive);
		}
		
	}
	public static class fulltime extends worker{
		public fulltime(double won , double incentive ) {
			super(10000*won, incentive);
		}
		public int pay(double n1, double n2, double n3) {//method overloading
			return (int)(super.pay(n1, n2)*n3);
		}	
	}

	public static void main(String[] args) {
		FileReader fr = null;
		FileWriter fw = null;	
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			fr = new FileReader("input.txt");
			br = new BufferedReader(fr);
			fw = new FileWriter("output.txt",false);
			bw = new BufferedWriter(fw);
			String s = null;
			s = br.readLine();
			StringTokenizer l = new StringTokenizer(s," ");
			int i = Integer.parseInt(l.nextToken());
			int j = Integer.parseInt(l.nextToken());
			Parttime[] a1 = new Parttime[i];//save data of worker as array
			fulltime[] a2 = new fulltime[j];
			bw.write("- Worker list");
			bw.newLine();
	
			for(;i != 0;i--){//save parttime worker's data
				s = br.readLine();
				StringTokenizer line = new StringTokenizer(s," ");
				a1[a1.length-i] = new Parttime(Double.parseDouble(line.nextToken()),Double.parseDouble(line.nextToken()));
				bw.write("p"+(a1.length-i+1));
				bw.newLine();
			}
			for(;j != 0;j--){//save fulltime worker's data
				s = br.readLine();
				StringTokenizer line = new StringTokenizer(s," ");
				a2[a2.length-j] = new fulltime(Double.parseDouble(line.nextToken()),Double.parseDouble(line.nextToken()));
				bw.write("f"+(a2.length-j+1));
				bw.newLine();
			}
			s = br.readLine();
			bw.newLine();
			while((s=br.readLine())!=null){
				StringTokenizer line = new StringTokenizer(s," ");
				String s1 = line.nextToken();
				String s2 = line.nextToken();
				String[] s2arr = s2.split("\\(|\\)");
				//calculate pay for worker
				if (s1.substring(0,1).equals("p")) {//parttime worker
					bw.write(s1+" "+s2+": ");
					int k = a1[Integer.parseInt(s1.substring(1,2))-1].pay(Double.parseDouble(s2arr[0]),Double.parseDouble(s2arr[1]));
					bw.write(Integer.toString(k));
					bw.newLine();
				}
				if (s1.substring(0,1).equals("f")) {//fulltime worker
					String s3 = line.nextToken();
					bw.write(s1+" "+s2+" "+s3+": ");
					int k = a2[Integer.parseInt(s1.substring(1,2))-1].pay(Double.parseDouble(s2arr[0]),Double.parseDouble(s2arr[1]),Double.parseDouble(s3));
					bw.write(Integer.toString(k));
					bw.newLine();
				}
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(br != null) try{br.close();}catch(IOException e){}
			if(fr != null) try{fr.close();}catch(IOException e){}
			if(bw != null) try{bw.close();}catch(IOException e){}
			if(fw != null) try{fw.close();}catch(IOException e){}
		}

	}

}
