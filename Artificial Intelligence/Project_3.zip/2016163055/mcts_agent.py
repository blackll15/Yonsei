# -*- coding: utf-8 -*-
"""
Monte-Carlo Tree Search implementation
"""
__author__ = 'Hyunsoo Park, Game AI Lab, NCSOFT'


import sys
import time
import random
import logging
from math import sqrt
from math import log
from operator import attrgetter
from collections import namedtuple
import chess

from scripts.run_game import State
from agents import BaseAgent

logging.basicConfig(format='[%(asctime)-15s] %(message)s')
logger = logging.getLogger('Game')
logger.setLevel(logging.INFO)
class Evaluator(object):
    """
    **bunch of evaluation methods**
    
    parameter is Chess.board and current turn(bool, white=True, black=False)
    return the evaluation score ([0, 1], float)
    """

    @staticmethod
    def win_or_lose(board, turn):
        """
        return win 1., lose 0., or draw 0.5

        - return 0.5 when draw or the game is not over

        :param State board: current game state
        :param bool turn: chess.WHITE or chess.BLACK
        :return: (float) -- [0, 1], float
        """
        if board.is_game_over():
            scores = board.result().split('-')
            for i, r in enumerate(scores):
                if r == '0':
                    scores[i] = 0.
                elif r == '1':
                    scores[i] = 1.
                elif r == '1/2':
                    scores[i] = 0.5
            if turn == chess.WHITE:
                return scores[0]
            elif turn == chess.BLACK:
                return scores[1]
        else:
            return 0.5

    @staticmethod
    def eval(board, turn):
        """
        evaluation method which evaluates piece score

        - if the game is over, use Evaluator.win_or_lose
        - else, calculate score considering the sort and number of pieces and normalize to a float number in [0, 1]
        - do not consider other status (the location of pieces, whether did castling, etc.)

        score for each piece

        - Pawn: 1 pt
        - Knight, Bissop: 3 pts
        - Rook: 5 pts
        - Queen: 10 pts
        - King: 4 pts

        :param State board: state to evaluate
        :param bool turn: chess.WHITE or chess.BLACK
        :return: (float) -- [0, 1], float
        """
        if board.is_game_over():
            return Evaluator.win_or_lose(board, turn)
        else:
            pieces = board.fen().split(' ')[0]
            black_scores, white_scores = 0, 0
            for p in pieces:
                if p == 'p':
                    black_scores += 1
                elif p == 'b':
                    black_scores += 3
                elif p == 'n':
                    black_scores += 4.5
                elif p == 'r':
                    black_scores += 5
                elif p == 'q':
                    black_scores += 10
                elif p == 'k':
                    black_scores += 4
                elif p == 'P':
                    white_scores += 1
                elif p == 'B':
                    white_scores += 3
                elif p == 'N':
                    white_scores += 4.5
                elif p == 'R':
                    white_scores += 5
                elif p == 'Q':
                    white_scores += 10
                elif p == 'K':
                    white_scores += 4

            assert turn in [chess.WHITE, chess.BLACK]
            score = 0.
            if turn == chess.WHITE:
                score = white_scores / (white_scores + black_scores)
            elif turn == chess.BLACK:
                score = black_scores / (white_scores + black_scores)
            return score

    @staticmethod
    def eval_2(board, turn):
        """
        change the result of Evaluator.eval ([0, 1], float) to [-1, 1], float

        :param State board: the state to evaluate
        :param bool turn: chess.WHITE or chess.BLACK
        :return: (float) -- [-1, 1], float
        """
        return 2. * Evaluator.eval(board, turn) - 1.


class MCTSAgent(BaseAgent):
    """
    MCTS AI
    
    maximize number of simulation steps and limit the search time
    utilize given time as much as possible
    """
    planner = None
    n_simulations = 1000
    search_time = 2
    max_depth = 6

    def reset(self):

        # the core function of MCTS agent is in this planner
        self.planner = MCTSPlanner(self.turn,
                                   max_depth=self.max_depth,
                                   action_score='visits',
                                   eval_func=Evaluator.eval_2,
                                   reward_amplify=True,
                                   exploration_coef=1.0,
                                   debug=False)

    def act(self, state):
        return self.planner.search(state.copy(), n_simulations=self.n_simulations, timeout=self.search_time)

    def close(self):
        pass

class Node(object):
    """
    node of MCTS

    Attrs:

    - (bool) -- color, white=True, black=False
    - (:class:`scripts.run_game.State`) -- state
    - (:class:`agents.search.macts_agent.Node`) -- parent, the parent node of current node
    - (dict) -- children, dict(key-> chess.Move, value-> Node), the state after given action
    - (int) -- visits, the number of visit to this node
    - (float) -- wins, the total rewards for this node
    - (float) -- ucb, ucb value of this node
    """

    # limit the attributes of this class for memory saving purpose
    __slots__ = ['turn', 'state', 'parent', 'children',
                 'ucb', 'wins', 'visits']
    
    def __init__(self, turn, state):
        self.turn = turn
        self.state = state
        self.parent = None
        self.children = dict()
        self.visits = 0
        self.wins = 0.
        self.ucb = -1

    @property
    def next_turn(self):
        return not self.turn
        
    def __repr__(self):
        return self._print_tree()
    
    def _print_tree(self, move=None, depth=0):
        """
        print tree on console
        """
        fmt = '{}:: {}-> v:{} vl:{:.3f} ({:.3f}) u:{:.3f} {}\n'
        buff = ''
        buff += '  ' * depth + fmt.format('White' if self.next_turn else 'Black',
                                          str(move),
                                          self.visits, self.wins,
                                          self.wins / (self.visits + 1e-6),
                                          self.ucb,
                                          self.state.fen())
        for move, c_node in self.children.items():
            buff += c_node.print_tree(move, depth + 1)
        return buff

    @property
    def key(self):
        return self.state.fen()

class MCTSPlanner(object):
    """
    MCTS algorithm implementation
    """
    
    def __init__(self, color, max_depth=sys.maxsize, action_score='visits',
                 eval_func=Evaluator.eval_2, exploration_coef=1.0,
                 reward_amplify=True, debug=False):
        self.turn = color
        self.max_depth = max_depth
        self._depth = 0
        self.action_score = action_score
        self.eval_func = eval_func
        self.ucb_c = exploration_coef
        self.reward_amplify = reward_amplify
        self.memory = dict()
        self.debug = debug
        
    def search(self, state, n_simulations=1000, timeout=10):
        """
        search under the condition (number of simulation steps and time limit)
        return the best action

        :param State state: current game state
        :param int n_simulations: the maximum number of simulations
        :param int timeout: time limit (sec.)
        :return: (chess.Move) -- the best action this AI found
        """
        v0 = Node(self.turn, state)
        # do not trash the search tree in previous search, reuse some of that
        v0 = self.memory.get(v0.key, v0)
        logger.debug('# of reuse nodes: {}'.format(v0.visits))
        self.memory.clear()

        start_time = time.perf_counter()
        simulation_count = 0
        while True:
            if simulation_count > n_simulations or time.perf_counter() - start_time > 0.99 * timeout:
                # if one of the condition is false, end the simulation
                color = 'White' if self.turn else 'Black'
                elapsed_time = time.perf_counter() - start_time
                simulation_per_sec = simulation_count / elapsed_time
                logger.debug('{}: Simulation speed: {:,.1f} (# of simulations: {:,}, elapsed {:.1f} sec.)'.format(
                    color, simulation_per_sec, simulation_count, elapsed_time))
                break

            self._depth = 0
            # selection and expansion
            vl = self.tree_policy(v0)
            # Monte-Carlo simulation
            delta = self.default_policy(vl.state)

            # amplify the reward signal
            if self.reward_amplify:
                current_value = self.eval_func(v0.state, self.turn)
                if delta > current_value:
                    delta = 1.0
                elif delta < current_value:
                    delta = -1.0
                else:
                    delta = 0.0

            # reward backpropagation
            self.backup(vl, delta)
            simulation_count += 1

            if self.action_score == 'visits':
                max_visits = max([v.visits for v in v0.children.values()])
                
        return self.best_child(v0).action
    
    def tree_policy(self, node):
        """
        selection and expansion
        
        :param agents.search.macts_agent.Node node: the current node v0
        :return: (Node) -- the expanded or selected (no expansion by the max depth condition) node vl
        """
        while not node.state.is_game_over() and self._depth < self.max_depth:
            untried = [action for action in node.state.legal_moves 
                       if action not in node.children.keys()]
            if untried:
                # if there is actions which is not tried, try them.
                
                # randomly choose
                selected = untried[random.randint(0, len(untried)-1)]
                # expansion
                next_state = node.state.forward(selected)
                child = Node(node.next_turn, next_state)
                node.children[selected] = child
                child.parent = node
                node = child
                break
            else:
                # calculate UCB score and choose the best one
                for child in node.children.values():
                    child.ucb = child.wins / child.visits + self.ucb_c * sqrt(2 * log(node.visits) / child.visits)
                    child.ucb += random.gauss(0, 1e-6)
                node = max(list(node.children.values()), key=attrgetter('ucb'))

            self.memory[node.key] = node
            self._depth += 1

        return node
    
    def default_policy(self, state):
        """
        Monte Carlo simulation
        
        :param State state: the state in returned node by tree_policy
        :return: (float) -- the reward from simulation
        """
        while not state.is_game_over() and self._depth < self.max_depth:
            actions = list(state.legal_moves)
            action = actions[random.randint(0, len(actions)-1)]
            state = state.forward(action)
            self._depth += 1

        return self.eval_func(state, self.turn)
    
    def backup(self, node, delta):
        """
        update the result of simulation
        change the sign of reward when the turn is changed
        assume that the reward interval is [-1, 1]
        
        :param agents.search.macts_agent.Node node: returned node by tree_policy
        :param float delta: the reward obtained from simulation
        """

        if node.parent.turn != self.turn:
            # negate the reward when the simulation is end at opponent's turn
            delta = -delta

        while node is not None:
            # from the node returned by tree_policy to root node, add reward and the number of visits
            node.wins += delta 
            node.visits += 1
            node = node.parent
            # negate the reward
            delta = -delta
    
    def best_child(self, node):
        """
        return the action with the highest value in current node

        :param agents.search.macts_agent.Node node: the current state in node v0
        :return: (chess.Move) -- the best action
        """
        Result = namedtuple('Result', ['action', 'visits', 'wins', 'ucb', 'value'])
        moves = [Result(move, node.visits, node.wins, node.ucb, node.wins / node.visits)
                 for move, node in node.children.items()]
        best_move = max(moves, key=attrgetter(self.action_score))  # select the action with the highset number of visits
        return best_move


if __name__ == '__main__':

    import chess
    from tqdm import trange
    my_color = chess.WHITE
    state = State()
    
    planner = MCTSPlanner(my_color)
    v0 = Node(my_color, state)

    for _ in trange(1000):
        planner._depth = 0
        vl = planner.tree_policy(v0)
        delta = planner.default_policy(vl.state)
        planner.backup(vl, delta)
    action = planner.best_child(v0)
    
    print(v0)
    print(action)
