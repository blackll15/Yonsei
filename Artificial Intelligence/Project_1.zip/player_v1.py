from kalah import reverse_board
from runner import Player, Mercy


class User(Player):
    def __init__(self):
        super().__init__()
        self.mercy = Mercy()
        '''
        Check Player class in runner.py to get information about useful predefined functions
        e.g. move, get_score, is_empty, step
        '''        
    def search(self, board, step=1):
        '''
        board: board information before move
        step: # of steps after move
        '''
        fvalue = []
        idx = []
        for i in range(6):
            if not self.is_empty(i,board,True):
                newboard, end = self.step(i,board,True)
                if end:
                    idx.append(i)
                    fvalue.append(self.f(step, newboard))
                else:
                    newboard1, end1 = self.step(self.mercy.response(i), newboard,False)
                    if end1:
                        idx.append(i)
                        fvalue.append(self.f(step+1, newboard1))
                    else:
                        for j in range(6):
                            if newboard1 != None and not self.is_empty(j,newboard1,True):
                                newboard2, end2 = self.step(j,newboard1,True)
                                idx.append(10*j+i)
                                fvalue.append(self.f(step+2,newboard2))
        
        return idx[fvalue.index(min(fvalue))]%10


    def f(self, step, board):
         return self.g(step, board)+self.h(board)   

    def g(self, step, board):
        '''
        cost function
        '''
        return step - self.get_score(board) + self.get_score(board, is_mine=False)
    
    def h(self, board): #Not implemented!
        '''
        heuristic function
        v1: h1
        v2: h1 + h21 + h22
        '''
        return self.h1(board)
        
    def h1(self, board):
        '''
        (# of pieces in holes in oppo’s side) - (# of pieces in holes in user side)
        '''
        total = 0
        for i in range(6):
            total += board[i+7]
        for i in range(6):
            total -= board[i]
        return total
    
    def h21(self, board):
        '''
        (# of oppo’s f-holes) - (# of user’s f-holes)
        '''
        total = 0
        for i in range(6):
            if board[i+7]+i+7 == 13:
                total += 1
        for i in range(6):
            if board[i]+i == 6:
                total -= 1
        return total

    def h22(self, board):
        '''
        {(# of pieces in oppo’s c-hole) + (# of oppo’s c-hole)} – {(# of pieces in user’s c-hole) + (# of user’s c-hole)}
        '''
        total = 0
        for i in range(6):
            if(board[12-i] == 0):
                for j in range(7,13):
                    if(board[j] != 0 and (board[j]+j)%14 == 12-i):
                        total += board[i]+1
                        break
        
        for i in range(7, 13):
            if(board[12-i] == 0):
                for j in range(6):
                    if(board[j] != 0 and (board[j]+j)%14 == 12-i):
                        total -= board[i]+1
                        break
        return total