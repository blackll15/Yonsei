function SNmanager(attributes){
    this.root = null;
    this.gss = {}; 
    this.nodeDict = {};
    this.attributes = attributes;
	this.selectNode=[];
	this.returnNode=[];
	this.visited_node=[];
}

SNmanager.prototype.init= function(){
    this.root = new Node('root','me');
    var gssList = ['food','sleep','activity'];
    for(var i=0; i<gssList.length; i++){
        var gssNode= new Node('gss', gssList[i]);
        this.gss[gssList[i]] = gssNode;
        this.addNode(this.root, gssNode);
    }
}

SNmanager.prototype.makeSN = function(dataset){
    for(var idx=0; idx<dataset.length; idx++){
        var one_data = dataset[idx];
        var startNode = new Node(this.attributes[0],one_data[0]);
        this.nodeDict[this.attributes[0]+","+one_data[0]] = startNode;
        var activityAttributeIndex = this.attributes.indexOf('activity'); 
        var targetGss = this.linkStartNode2gssNode(one_data[activityAttributeIndex]);
        this.addNode(targetGss, startNode);

        for(var j=0; j<(this.attributes.length-1); j++) {
            if(one_data[j+1] == '/' || one_data[j+1] == '') {
                continue;
            }//([this.attributes[j+1], one_data[j+1]] in this.nodeDict)
            var tmpNode = new Node(this.attributes[j+1], one_data[j+1]);//this.nodeDict.hasOwnProperty([this.attributes[j+1], one_data[j+1]]
			/*this.nodeDict[this.attributes[j+1], one_data[j+1]]!=undefined
			if( this.nodeDict[this.attributes[j+1], one_data[j+1]] != undefined ){
				this.addNode(startNode, this.nodeDict[this.attributes[j+1], one_data[j+1]]);		
                continue;
                console.log('coupled');
            }*/
			if([this.attributes[j+1]+","+ one_data[j+1]] in this.nodeDict){
				this.addNode(startNode, this.nodeDict[this.attributes[j+1]+","+ one_data[j+1]]);
                continue;
                console.log('coupled');
            }
            this.nodeDict[this.attributes[j+1]+","+ one_data[j+1]] = tmpNode;
            this.addNode(startNode, tmpNode);
        }
    }
}
SNmanager.prototype.addNode = function(from, to){
    var edge= new Edge(from,to);

    from.children_list.push(to);
    to.parents_list.push(from);

    from.edge_list.push(edge);
    to.edge_list.push(edge);
}

SNmanager.prototype.linkStartNode2gssNode = function(activity){
    if (activity.indexOf('잠')!=-1 || activity.indexOf('수면')!=-1 || activity.indexOf('취침')!=-1){
        return this.gss['sleep'];
    }
    if (activity.indexOf('식사')!=-1 || activity.indexOf('아침')!=-1 || activity.indexOf('점심')!=-1 || activity.indexOf('저녁')!=-1 || activity.indexOf('밥')!=-1){
        return this.gss['food'];
    }
    return this.gss['activity'];
}

/*
 * edited by hj
 */
// 두 날짜의 차이 return
// date2는 항상 date1보다 같거나 늦은 날짜여야함
// 입력 date형식: string, "yyyy-mm-dd"
// 출력: Number, 두 날짜 차이
SNmanager.prototype.dayDiff = function(date1, date2){
    var oneday_ms = 1000*60*60*24;

    var sp = date1.split('-');  //[yyyy, mm, dd]
    var dateob1 = new Date(sp[0], sp[1]-1, sp[2]); //month is 0 to 11
    sp = date2.split('-');
    var dateob2 = new Date(sp[0], sp[1]-1, sp[2]);

    var d1_ms = dateob1.getTime();
    var d2_ms = dateob2.getTime();

    var diff_ms = d2_ms - d1_ms;

    var diff_day = Math.round(diff_ms / oneday_ms);

    return diff_day;
}

// edited by hj
//
// search 함수, 주어진 키워드에 따라 검색 후 해당 노드의 값 리턴
// gss value, 시작시간, 끝시간, attribute를 입력으로 받아
// 해당 attribute에 대한 node들이 있는지 탐색함, 있다면 그 노드들의 값들을 return.
// 주의: 시간에 어떤 날짜의 15시~17시를 입력으로 받았다면 15시~17시 59분까지 결과에 포함됨
SNmanager.prototype.searchNode = function(gss, stime, etime, attribute, activity_which){ //<-main에서 function4에 의해 인자 받음
    // 입력을 잘못하면 사용법 출력
    if (
        (gss != 'activity' && gss != 'sleep' && gss != 'food')
        || stime == ''
        || etime == ''
        || attribute == ''
    ) {
        var usage = []

        usage.push(["","Usage(ex)",""]);
        usage.push(["","gss","activity/sleep/food"]);
        usage.push(["","start-time","yyyy-mm-dd-hh"]);
        usage.push(["","end-time","yyyy-mm-dd-hh(later than start-time)"]);
        usage.push(["","attribute","activity/place/person/..."]);
        usage.push(["","activity_which","gss가 activity면 입력, 업무|(세부활동)/청소/..."]);
        usage.push(["","activity_which","빈칸 입력시, 모든 activity 출력"]);
        return usage;
    }

    // 요약 정보 위한 변수
    var emote;
    var tired;
    var time1;
    var time2;
    var sleepmin;
    var sleephour;
    var mealtype;
    var aof;

    // 요약 정보
    var node_count = 0; //총 탐색된 노드 수
    var avg_emotion = 0;
    var num_hunger = 0;
    var avg_tiredness = 0;
    var time_sleep = 0;
    var num_breakfast = 0;
    var num_lunch = 0;
    var num_dinner = 0;
    var num_snack = 0;
    var num_midnight = 0;
    var num_mealetc = 0;
    var avg_aof = 0;
    var num_inside = 0;
    var act_dict = {};  //for (var key in act_dict)


    var gssNode = this.gss[gss];

    //시작노드들 중에서 그 시간대(YYYY-MM-DD-HH)에 있는 시작노드 list 들고옴.
    var query_s_split =  stime.split("-");
    var s_date = query_s_split[0] + "-" + query_s_split[1] + "-" + query_s_split[2];
    var s_hour = query_s_split[3];

    var query_e_split =  etime.split("-");
    var e_date = query_e_split[0] + "-" + query_e_split[1] + "-" + query_e_split[2];
    var e_hour = query_e_split[3];

    var daydiff = this.dayDiff(s_date, e_date);

    var dateerror = 0;
    var highlightedStartNodeList = [];
    for(var i=0; i < gssNode.children_list.length; i++){
        var node_split = gssNode.children_list[i].value.split(" "); // 0: date, 1: hh:mm:ss
        var node_hour = node_split[1].split(":");
        node_hour = node_hour[0]

        // 검색하고자하는 두 날짜가 같은 날짜
        if (daydiff == 0) {
            // node_date(node_split[0])는 해당 날짜인지
            // 그렇다면 node_hour가 shour, ehour 사이인지
            if(s_date == node_split[0] && s_hour <= node_hour && node_hour <= e_hour) {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
        }
        // 하루 차이
        else if (daydiff == 1) {
            //node_date가 s_date면, node_hour가 s_hour부터 24:00까지인지
            if(s_date == node_split[0] && s_hour <= node_hour && node_hour <= "24") {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
            //node_date가 e_date면, node_hour가 00:00부터 e_hour까지인지
            else if(e_date == node_split[0] && "00" <= node_hour && node_hour <= e_hour) {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
        }
        // 2일 이상 차이
        else if (daydiff > 1) {
            //node_date가 s_date면, node_hour가 s_hour부터 24:00까지인지
            if(s_date == node_split[0] && s_hour <= node_hour && node_hour <= "24") {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
            //node_date가 s_date, e_date 사이인지
            else if(s_date <= node_split[0] && node_split[0] <= e_date) {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
            //node_date가 e_date면, 00:00부터 e_hour까지
            else if(e_date == node_split[0] && "00" <= node_hour && node_hour <= e_hour) {
                highlightedStartNodeList.push(gssNode.children_list[i]);
            }
        }
        else { dateerror += 1; }
    }

    //각 시작노드에서 'attribute' 파라미터를 attribute로 가지는 노드의 값 + 종료시간 노드의 값을 시작 순서대로 리포팅
    var highligtedProperties = [] // 추후 확장성을 위하여 각 값 변수에 저장

    // gss가 activity인 경우 5번째 인자인 activity_which(세부 활동명)에 따라 노드 필터링(activity_which가 없으면, 모든 활동 출력)
    // 세부 활동은 업무, 청소, 봉사, 사교, 공부, 수동적 여가, 능동적 여가, 야외활동, 이동, 기타 중 하나
    // 세부 활동의 상세 내용을 입력하지 않으면 해당 항목을 모두 찾음 (| 뒤의 요소)
    // 예를 들어, 실제 데이터에 야외 활동|산책 이라는 항목과 야외 활동|운동 이라는 항목이 있으면,
    // query의 activity_which로 야외 활동만 입력했을 경우 둘 모두를 찾게 됨.
    // 반면, 야외 활동|산책 또는 야외 활동|운동 을 입력했을 경우 해당하는 것만 찾게 됨.
    if (gss == 'activity') {
        var temp_active_list = [];
        var cur_activity = "";
        for(var i=0; i < highlightedStartNodeList.length; i++) {
            cur_activity = highlightedStartNodeList[i].getChildByAttr('activity').value;
            if (cur_activity.indexOf(activity_which) >= 0) {
                temp_active_list.push(highlightedStartNodeList[i]);
            }
        }

        for(var i=0; i < temp_active_list.length; i++) {
            var tmp_list = [];

            //요약 정보 업데이트
            node_count += 1;
            emote = temp_active_list[i].getChildByAttr('emotion').value;
            tired = temp_active_list[i].getChildByAttr('tiredness').value;

            //emotion = {매우 부정, 부정, 보통, 긍정, 매우 긍정}
            if(emote == '매우부정' || emote == '매우 부정') {avg_emotion += 1;}
            else if(emote == '부정') {avg_emotion += 2;}
            else if(emote == '긍정') {avg_emotion += 4;}
            else if(emote == '매우긍정' || emote == '매우 긍정') {avg_emotion += 5;}
            else {avg_emotion += 3;}

            //hunger = {예, 아니오}
            if(temp_active_list[i].getChildByAttr('hunger').value == '예') {num_hunger += 1;}

            //tiredness = {매우 낮음, 낮음, 높음, 매우 높음}
            if(tired == '매우낮음' || tired == '매우 낮음') {avg_tiredness += 1;}
            else if(tired == '낮음') {avg_tiredness += 2;}
            else if(tired == '높음') {avg_tiredness += 3;}
            else if(tired == '매우높음' || tired == '매우 높음') {avg_tiredness += 4;}
            else {avg_tiredness += 2.5;}

            //location = {실내, 실외}
            if(temp_active_list[i].getChildByAttr('location').value == '실내') {num_inside += 1;}

            //act_dict
            if(temp_active_list[i].getChildByAttr('activity').value in act_dict) {
                act_dict[temp_active_list[i].getChildByAttr('activity').value] += 1;
            }
            else {
                act_dict[temp_active_list[i].getChildByAttr('activity').value] = 1;
            }


            //search 결과 list에 노드 정보 추가
            tmp_list.push(temp_active_list[i].value);
            tmp_list.push(temp_active_list[i].getChildByAttr('end_time').value);
            tmp_list.push(temp_active_list[i].getChildByAttr(attribute).value);

            highligtedProperties.push(tmp_list);
            // console.log(tmp_list[0] + "  ~  " + tmp_list[1] + '   : ' + tmp_list[2]);
        }
    }

    // gss가 activity가 아니면 5번째 인자 사용x
    else {
        for(var i=0; i < highlightedStartNodeList.length; i++) {
            var tmp_list = [];

            //요약 정보 업데이트
            node_count += 1;
            if(highlightedStartNodeList[i].getChildByAttr('emotion') != null) {
                emote = highlightedStartNodeList[i].getChildByAttr('emotion').value;
            }
            if(highlightedStartNodeList[i].getChildByAttr('tiredness') != null) {
                tired = highlightedStartNodeList[i].getChildByAttr('tiredness').value;
            }

            //emotion = {매우 부정, 부정, 보통, 긍정, 매우 긍정}
            if(emote == '매우부정' || emote == '매우 부정') {avg_emotion += 1;}
            else if(emote == '부정') {avg_emotion += 2;}
            else if(emote == '긍정') {avg_emotion += 4;}
            else if(emote == '매우긍정' || emote == '매우 긍정') {avg_emotion += 5;}
            else {avg_emotion += 3;}

            //hunger = {예, 아니오}
            if(highlightedStartNodeList[i].getChildByAttr('hunger') != null) {
                if(highlightedStartNodeList[i].getChildByAttr('hunger').value == '예') {num_hunger += 1;}
            }

            //tiredness = {매우 낮음, 낮음, 높음, 매우 높음}
            if(tired == '매우낮음' || tired == '매우 낮음') {avg_tiredness += 1;}
            else if(tired == '낮음') {avg_tiredness += 2;}
            else if(tired == '높음') {avg_tiredness += 3;}
            else if(tired == '매우높음' || tired == '매우 높음') {avg_tiredness += 4;}
            else {avg_tiredness += 2.5;}

            //location = {실내, 실외}
            if(highlightedStartNodeList[i].getChildByAttr('location') != null) {
                if(highlightedStartNodeList[i].getChildByAttr('location').value == '실내') {num_inside += 1;}
            }


            if(gss == 'sleep') {
                time1 = highlightedStartNodeList[i].value;
                time2 = highlightedStartNodeList[i].getChildByAttr('end_time').value;

                time1 = time1.split(" ");
                time2 = time2.split(" ");

                time1 = time1[1].split(":");
                time2 = time2[1].split(":");
                sleepmin = Number(time2[0])*60 + Number(time2[1]) - Number(time1[0])*60 - Number(time1[1]);
                //console.log(sleepmin);

                time_sleep += sleepmin;
            }

            else if(gss == 'food') {

                if(highlightedStartNodeList[i].getChildByAttr('meal_type') != null) {
                    mealtype = highlightedStartNodeList[i].getChildByAttr('meal_type').value;
                }
                if(highlightedStartNodeList[i].getChildByAttr('amount_of_food') != null){
                    aof = highlightedStartNodeList[i].getChildByAttr('amount_of_food').value;
                }

                //mealtype = {아침, 점심, 저녁, 간식, 야식, 기타}
                if(mealtype.indexOf('아침') == 0) {num_breakfast += 1;}
                else if(mealtype.indexOf('점심') == 0) {num_lunch += 1;}
                else if(mealtype.indexOf('저녁') == 0) {num_dinner += 1;}
                else if(mealtype.indexOf('간식') == 0) {num_snack += 1;}
                else if(mealtype.indexOf('야식') == 0) {num_midnight += 1;}
                else if(mealtype.indexOf('기타') == 0) {num_mealetc += 1;}

                //amount of food = {매우 적음, 적음, 많음, 매우 많음}
                if(aof == '매우적음' || aof == '매우 적음') {avg_aof += 1;}
                else if(aof == '적음') {avg_aof += 2;}
                else if(aof == '많음') {avg_aof += 3;}
                else if(aof == '매우많음' || aof == '매우 많음') {avg_aof += 4;}
                else {avg_aof += 2.5}
            }

            if(highlightedStartNodeList[i].getChildByAttr(attribute) != null) {
                tmp_list.push(highlightedStartNodeList[i].value);
                tmp_list.push(highlightedStartNodeList[i].getChildByAttr('end_time').value);
                tmp_list.push(highlightedStartNodeList[i].getChildByAttr(attribute).value);
            }

            highligtedProperties.push(tmp_list);
            // console.log(tmp_list[0] + "  ~  " + tmp_list[1] + '   : ' + tmp_list[2]);
        }
    }

    // 날짜 입력이나 계산 과정에서 문제 발생
    for(var i = 0; i < dateerror; i++) {
        highligtedProperties.push(["","","something wrong in treating dates"]);
    }

    // 요약정보
    // start-date부터 end-date 기간 동안의 위에서 탐색된 노드들에 대한 정보
    highligtedProperties.push(["", "요약", ""]);

    avg_emotion = avg_emotion / node_count;
    if(avg_emotion < 1.5) avg_emotion = '매우 부정';
    else if(avg_emotion < 2.5) avg_emotion = '부정';
    else if(avg_emotion < 3.5) avg_emotion = '보통';
    else if(avg_emotion < 4.5) avg_emotion = '긍정';
    else avg_emotion = '매우 긍정';

    avg_tiredness = avg_tiredness / node_count;
    if(avg_tiredness < 1.5) avg_tiredness = '매우 낮음';
    else if(avg_tiredness < 2.5) avg_tiredness = '낮음';
    else if(avg_tiredness < 3.5) avg_tiredness = '높음';
    else avg_tiredness = '매우 높음';

    highligtedProperties.push(["", "검색된 노드 수", node_count]);
    highligtedProperties.push(["", "배고픔 수", num_hunger]);
    highligtedProperties.push(["", "평균 감정", avg_emotion]);
    highligtedProperties.push(["", "평균 피로도", avg_tiredness]);
    highligtedProperties.push(["", "실내 활동", num_inside]);
    highligtedProperties.push(["", "실외 활동", node_count - num_inside]);

    if (gss == 'activity') {
        console.log("gss is activity");
        highligtedProperties.push(["", "활동 횟수", ""]);
        for(var key in act_dict) {
            highligtedProperties.push(["", key, act_dict[key]]);
        }
    }

    if (gss == 'sleep') {
        console.log("gss is sleep");
        sleephour = time_sleep / 60;
        sleephour = sleephour.toFixed(2);
        sleepmin = time_sleep % 60;



        time_sleep = Math.floor(sleephour) + "시간 " + sleepmin + "분";
        console.log(daydiff);
        highligtedProperties.push(["", "총 수면 시간", time_sleep]);
        highligtedProperties.push(["", "총 수면 횟수(추정)", node_count-daydiff-1]);
        highligtedProperties.push(["", "수면당 평균 수면 시간(추정)", (sleephour / (node_count-daydiff-1)).toFixed(2)]);
        highligtedProperties.push(["", "일일 평균 수면 시간", (sleephour / (daydiff+1)).toFixed(2)]);
        highligtedProperties.push(["", "일일 평균 수면 횟수(추정)", (node_count-daydiff-1) / (daydiff+1)]);
    }

    if (gss == 'food') {
        console.log("gss is food");
        avg_aof = avg_aof / node_count;

        if(avg_aof < 1.5) avg_aof = '매우 적음';
        else if(avg_aof < 2.5) avg_aof = '적음';
        else if(avg_aof < 3.5) avg_aof = '많음';
        else avg_aof = '매우 많음';

        highligtedProperties.push(["", "평균 식사량", avg_aof]);
        highligtedProperties.push(["", "식사 종류", ""]);
        highligtedProperties.push(["", "아침", num_breakfast]);
        highligtedProperties.push(["", "점심", num_lunch]);
        highligtedProperties.push(["", "저녁", num_dinner]);
        highligtedProperties.push(["", "간식", num_snack]);
        highligtedProperties.push(["", "야식", num_midnight]);
        highligtedProperties.push(["", "기타", num_mealetc]);
    }

    return highligtedProperties;
};

//네트워크 노드의 ID를 재귀적으로 탐색
SNmanager.prototype.getNodeById = function (id) {
    const search = (node) => {
        if (node.attribute + node.value === id) {
            return node
        }

        for (const child_node of node.children_list) {
            const found = search(child_node)

            if (found !== null) {
                return found
            }
        }

        return null
    }

    return search(this.root)
}


/*SNmanager.prototype.searchNode = function(gss, time, attribute){
    var gssNode = this.gss[gss];
    var query_split =  time.split("-");
    var query_date = query_split[0] + "-" + query_split[1] + "-" + query_split[2];
    var query_hour = query_split[3];

    var highlightedStartNodeList = [];
    for(var i=0; i < gssNode.children_list.length; i++){
        var node_split = gssNode.children_list[i].value.split(" "); 
        var node_hour = node_split[1].split(":");
        node_hour = node_hour[0]
        if(query_date == node_split[0] && query_hour == node_hour){
            highlightedStartNodeList.push(gssNode.children_list[i]);
        }
    }
    var highligtedProperties = [] 

    for(var i=0; i < highlightedStartNodeList.length; i++) {
        var tmp_list = [];

        tmp_list.push(highlightedStartNodeList[i].value);
        tmp_list.push(highlightedStartNodeList[i].getChildByAttr('end_time').value);
        tmp_list.push(highlightedStartNodeList[i].getChildByAttr(attribute).value);
        highligtedProperties.push(tmp_list);
    }

    return highligtedProperties;
};*/

SNmanager.prototype.getNodeById = function (id) {
    const search = (node) => {
        if (node.attribute + node.value === id) {
            return node
        }

        for (const child_node of node.children_list) {
            const found = search(child_node)

            if (found !== null) {
                return found
            }
        }

        return null
    }

    return search(this.root)
}



//input으로 받은 a(list)에 대해서 하나씩 selectNode에 넣어준다. selectNode는 골라낼 attr, value를 의미한다.
SNmanager.prototype.getNode=function(a){
	for (var i=0 ; i<a.length ; i++ )
	{
		this.selectNode.push(a[i]);
	}
	//DFS를 통해 input에 해당하는 node면 returnNode(list)에 저장.
	//var returnNode = [];
	this.DFS(this.root);
	/*alert(this.returnNode.length+"!!");
	for (var l=0; l<this.returnNode.length; l++ )
	{
		alert(this.returnNode[l]);
	}*/
	return this.returnNode;
}

	
SNmanager.prototype.DFS=function(v){
	var S = new stack();
	
	//adjacent_list는부모와 자식노드들을 모두 합친 list
	S.push(v);
	while ( !(S.isEmpty()) )
	{
		
		var w = S.pop();
		//this.visited_node.push([w.attribute,w.value]);
		//alert(this.visited_node);
		
		if (!(this.visited_node.includes(w.attribute+""+w.value)))
		{
			//alert(2);
			this.visited_node.push(w.attribute+""+w.value);
			//alert(w.attribute+" "+w.value);
			if ((this.selectNode.includes(w.attribute)) || this.selectNode.includes(w.value))	{this.returnNode.push(w.attribute+","+w.value);}
			var adjacent_list = w.parents_list.concat(w.children_list);
			
			for (var k =0;k< adjacent_list.length; k++ )
			{
				//alert(adjacent_list[k].value);
				//!(this.visited_node.inclues([adjacent_lisk[k].attribute,advacent_list[k].value]))
				//!([adjacent_list[k].attribute,advacent_list[k].value] in this.visited_node
				if (!(this.visited_node.includes(adjacent_list[k].attribute+""+adjacent_list[k].value))) {	S.push(adjacent_list[k]);
				//alert(adjacent_list[k].attribute+","+adjacent_list[k].value);
				}
			}
		}
	}
	}


var stack = function(){
 this.datas = [];
}

stack.prototype.isEmpty = function(){
  return this.datas.length==0?true:false;
}
stack.prototype.length = function(){
 return this.datas.length;
}
stack.prototype.push = function(element){

 this.datas.push(element);
}
stack.prototype.pop = function(){
 element = this.peek();
 this.datas.pop();
 return element;
}

stack.prototype.peek = function(){
 element = this.datas[this.datas.length-1]==undefined?null:this.datas[this.datas.length-1];
 return element;
}
stack.prototype.toArray = function(){
 return this.datas;
}

