# sclab_SN_project
This page generated for wep demo implementation as part of Life loging project
