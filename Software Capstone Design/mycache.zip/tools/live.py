import sys
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time

#graph_data = open(sys.argv[1], 'r').read()

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

def animate(i):
	graph_data = open(sys.argv[1], 'r').read()
	dataArray = graph_data.split('\n')
	pt = []
	for line in dataArray:
		if len(line) > 1:
			pt.append(float(line))

	ax1.clear()
	ax1.plot(pt, 'r-', lw=0.6, color='#d65f5f')
	plt.grid(color='gray', linestyle='-.', linewidth=0.3)
	plt.tight_layout()

ani = animation.FuncAnimation(fig, animate, interval=1000)
plt.show()
