import sys
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import time

#graph_data = open(sys.argv[1], 'r').read()

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

def animate(i):
	graph_data = open(sys.argv[1], 'r').read()
	graph_data2 = open(sys.argv[2],'r').read()
	dataArray = graph_data.split('\n')
	dataArray2 = graph_data2.split('\n')
	pt = []
	pt2 = []
	for line in dataArray:
		if len(line) > 1:
			pt.append(float(line))
	for line in dataArray2:
		if len(line) > 1:
			pt2.append(float(line))

	ax1.clear()
	ax1.plot(pt, '-', lw=0.8, color='#e15759')
	ax1.plot(pt2,'-', lw=0.8, color='#4e79a7')
	plt.grid(color='gray', linestyle='-.', linewidth=0.2)
	plt.tight_layout()

ani = animation.FuncAnimation(fig, animate, interval=1000)
plt.show()

export DISPLAY=:0.0