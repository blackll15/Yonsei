import sys
import matplotlib.pyplot as plt
import numpy as np

import seaborn as sns

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

graph_data = open(sys.argv[1], 'r').read()
dataArray = graph_data.split('\n')
aa = np.array([np.zeros(128)])
la = []
cnt = 0


for line in dataArray:
	if len(line) > 1:
		line = line.split(" ")
		la = []
		cnt = 0
		for element in line:
			if element != " " and element != "":
				la = np.append(la, float(element))
		aa = np.vstack((aa, la))

ax1 = sns.heatmap(aa)
#ax1.imshow(aa, cmap='YlGnBu')
plt.show()