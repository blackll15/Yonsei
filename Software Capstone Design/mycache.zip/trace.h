#ifndef __TRACE_H__
#define __TRACE_H__
#include <inttypes.h>
#include <stddef.h>
#include <stdio.h>
#include <cstdio>
#include <stdlib.h>
#include <map>

#define PAGE_SIZE								4096
#define NUM_INSTR_DESTINATIONS	2
#define NUM_INSTR_SOURCES				4

typedef struct trace_instr_format
{
	uint64_t	ip;																							//* program counter
	uint8_t		is_brach;																				//* is this branch?
	uint8_t		branch_taken;																		//* if so, is this taken
	uint8_t		destination_register[NUM_INSTR_DESTINATIONS];		//* output registers
	uint8_t		source_registers[NUM_INSTR_SOURCES];						//* input registers
	uint64_t	destination_memory[NUM_INSTR_DESTINATIONS];			//*	output memory
	uint64_t	source_memory[NUM_INSTR_SOURCES];								//* input memory
} t_format;

size_t instr_size = sizeof(t_format);

uint32_t	maplog2(uint32_t n)
{
	uint32_t power; for (power=0; n>>=1; ++power);	return power;
}

class PageMapper
{
	public:
		virtual	~PageMapper() {}
		virtual uint64_t translate(uint64_t virtual_address) = 0;
		uint64_t getNumPhysicalPage()	{ return m_page_table.size(); }
	protected:
		std::map<uint64_t, uint64_t> m_page_table;
		uint32_t m_page_size;
		uint64_t m_physical_tag;
		PageMapper(uint32_t page_size, uint64_t physical_tag)
			: m_page_size(page_size), m_physical_tag(physical_tag) {}
};

class FCFSPageMapper : public PageMapper
{
	public:
		FCFSPageMapper(uint32_t page_size = PAGE_SIZE);
		~FCFSPageMapper();
	public:
		uint64_t translate(uint64_t virtual_address);
};

FCFSPageMapper::FCFSPageMapper(uint32_t page_size)
	: PageMapper(page_size, 0)
{
}

FCFSPageMapper::~FCFSPageMapper()
{
}

uint64_t FCFSPageMapper::translate(uint64_t virtual_address)
{
	uint64_t vpn = virtual_address >> (int)maplog2(m_page_size);
	uint64_t offset = virtual_address & (m_page_size - 1);

	std::map<uint64_t, uint64_t>::iterator it;
	it = m_page_table.find(vpn);

	if (it == m_page_table.end())
	{
		uint64_t physical_address = (m_physical_tag << (int)maplog2(m_page_size)) | offset;
		m_page_table[vpn] = m_physical_tag++;
		return physical_address;
	}
	else
	{
		return (it->second << (int)maplog2(m_page_size)) | offset;
	}	
}

#endif
