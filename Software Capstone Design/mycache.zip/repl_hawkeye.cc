#include "cache.h"
#include "repl_hawkeye.h"

void HawkEye_replace_addr_history_element(cache_t* _cache, unsigned int sampler_set)
{
  uint64_t lru_addr = 0;
  for (std::map<uint64_t, ADDR_INFO>::iterator it = _cache->addr_history->at(sampler_set).begin(); \
       it != _cache->addr_history->at(sampler_set).end(); it++)
  {
    if ((it->second).lru == (_cache->SAMPLER_WAY-1))
    {
      lru_addr = it->first;
      break;
    }
  }
  _cache->addr_history->at(sampler_set).erase(lru_addr);
}

void HawkEye_update_addr_history_lru(cache_t* _cache, unsigned int sampler_set, unsigned int curr_lru)
{
  for (std::map<uint64_t, ADDR_INFO>::iterator it = _cache->addr_history->at(sampler_set).begin(); \
       it != _cache->addr_history->at(sampler_set).end(); it++)
  {
    if ((it->second).lru < curr_lru)
    {
      (it->second).lru++;
      assert((it->second).lru < _cache->SAMPLER_WAY);
    }
  }
}

//* Sample 64 sets per core
bool SAMPLED_SET(uint64_t set, uint32_t num_cores, uint32_t LLC_SET)
{
	if (num_cores == 1)
		return (bits(set, 0, 6) == bits(set, ((unsigned long long)log2(LLC_SET) - 6), 6));
	else
		return (bits(set, 0, 8) == bits(set, ((unsigned long long)log2(LLC_SET) - 8), 8));
}