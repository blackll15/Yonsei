#include <stdio.h>
#include <inttypes.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "trace.h"
#include "cache.h"

#define		KB	1024
#define		MB	(KB*1024)

FILE *trace;
char gunzip_cmd[1024];

uint64_t cpu_cycle;

t_format current_instr;

uint32_t num_dest, num_sour, num_mem_ops, mem_cnt, num_instr;
uint64_t paddr;
uint32_t optype;
bool 		 mem_fetch;
bool		 trace_end;

uint64_t instr_limit;

uint32_t simu_instrs, simu_addr, simu_ip;

uint64_t executed_instrs = 0;

FCFSPageMapper* pMapper;

cache_t	*L1, *L2, *L3;
uint32_t	cache_busy_cycle = 0;

uint64_t	interval_clk;
uint64_t	interval_instr;

double print_large_div(uint64_t _val1, uint64_t _val2);
void open_trace(char* _path);
void read_trace();

Node* hashTable[512];

FILE* ipc;

int main(int argc, char** argv)
{
	for(int i = 0; i < 512; i++){
		hashTable[i] = NULL;
	}
	open_trace(argv[1]);

	cpu_cycle = 0;
	num_dest = 0; num_sour = 0; num_mem_ops = 0; mem_cnt = 0; num_instr = 0;
	mem_fetch = false;	trace_end = false;

	pMapper = new FCFSPageMapper();

	instr_limit = strtoull(argv[2], 0, 10);	//* instr_limit: limit the number of instructions being simulated.
	L1 = init_cache_structure(64*KB, 4, 0, 64, 3, SET_ASSOCIATE, true, false);
	L2 = init_cache_structure(256*KB, 8, 0, 64, 12, SET_ASSOCIATE, false, false);
	L3 = init_cache_structure(2*MB, 16, 0, 64, 32, SET_ASSOCIATE, false, true);

	ipc = fopen("ipc.log", "w");

	connect_cache(L1, L2);
	connect_cache(L2, L3);

	printf("== Simple cache simulator ==\n");
	printf("Max instructions: %llu\n", instr_limit);
	printf("Simulation starts..\n");



	while(1)
	{
		if (cache_busy_cycle == 0)
		{
			//* condition for the end of simulation
			if (feof(trace) || executed_instrs >= instr_limit)	trace_end = true;
			
			//* read_trace():
			//*  - simu_instrs: non-memory instructions (ADD, JMP, DIV, SUB, etc.) between two memory instructions.
			//*  - simu_addr:   physical memory address (real memory(cache) access).
			//*  - simu_ip:		 instruction pointer (Program Counter) of the current memory access instruction.
			if (!mem_fetch && !trace_end && (simu_instrs == 0))
			{
				read_trace();
			}

			if (simu_instrs > 0)
			{
				simu_instrs--;	//* run a non-memory instruction by one cycle
				executed_instrs++;
				interval_instr++;
			}
			else if (simu_instrs == 0 && mem_fetch)
			{
				cache_busy_cycle = do_cache_access(L1, simu_addr, simu_ip, false);
				mem_fetch = false;
			}
		}
		else
		{
			cache_busy_cycle--;
		}	

		if (interval_instr == 100000)
		{
			fprintf(ipc, "%.4lf\n", print_large_div(interval_instr, interval_clk));
			fflush(ipc);
			interval_clk = 0;
			interval_instr = 0;
		}

		if (trace_end && cache_busy_cycle==0)	break;

		cpu_cycle++;	//* update cpu cycle
		interval_clk++;
	}

	printf("Simulation ends..\n\n");

	printf("[Simulation Result]\n");
	printf("Total execution cycles: %llu\n", cpu_cycle);
	printf("Average IPC: %5.2lf (Instructions/cycle)\n", (double)executed_instrs / cpu_cycle);
	printf("L1$ hit rate: %.3lf%% (%llu,%llu)\n", (double)(L1->hit_cnt * 100) / L1->total_access_cnt, L1->hit_cnt, L1->total_access_cnt);
	printf("L2$ hit rate: %.3lf%% (%llu,%llu)\n", (double)(L2->hit_cnt * 100) / L2->total_access_cnt, L2->hit_cnt, L2->total_access_cnt);
	printf("L3$ hit rate: %.3lf%% (%llu,%llu)\n", (double)(L3->hit_cnt * 100) / L3->total_access_cnt, L3->hit_cnt, L3->total_access_cnt);

	FILE *heat_map;

	heat_map = fopen("heatmap.log", "w");
	for (uint32_t s=1; s<=L3->set; s++)
	{
		for (uint32_t w=1; w<=L3->way; w++)
		{

			double reuse_rate;
			if (L3->reuse[w-1][s-1].data_change > 0)
				reuse_rate = print_large_div(L3->reuse[w-1][s-1].reuse_hit, L3->reuse[w-1][s-1].data_change);
			else
				reuse_rate = 0.00;
			fprintf(heat_map, "%.3lf ", reuse_rate);
		}
		if (s % 8 == 0)
		{
			fprintf(heat_map, "\n");
		}
	}
	//WriteFile("map.txt", hashTable); //Write hashTable out to file
	return 0;
}
int WriteFile(std::string fname, Node* htable[]) 
{
    int count = 0;
 
    FILE *fp = fopen(fname.c_str(), "w");
    if (!fp) return -errno;
    for(int k = 0; k < 512; k++){
		if(htable[k] != NULL)
		{

	 		for(Node* curnode = htable[k]; curnode->hashNext != NULL; curnode = curnode->hashNext){
         		if (curnode == NULL) break;
				fprintf(fp, "%d=%d\n", curnode->id, curnode->hitc); //If you want distance data, correct to curnode->distance
	 			count++;
	 		}
		}
    }
    fclose(fp);
    return count;
}


double print_large_div(uint64_t _val1, uint64_t _val2)
{
	while(_val1>=1000 && _val2>=1000){_val1 /= 10; _val2 /= 10;}
	return (double)_val1 / (double)_val2;
}

//* void open_trace(char* _path): the function which open the trace file, compressed as xz format
void open_trace(char* _path)
{
	sprintf(gunzip_cmd, "xz -T 0 -dc %s", _path);
	trace = popen(gunzip_cmd, "r");
}

//* void read_tracet(): the function which reads trace file and extracts instruction information, including physical memory address, the number of instructions b/w memory operations, PC.
void read_trace()
{
	num_instr = 0;
	while(1)
	{
		if (num_mem_ops == 0)
		{
			fread(&current_instr, instr_size, 1, trace);
			num_dest = 0;
			num_sour = 0;
			num_mem_ops = 0;
			mem_cnt = 0;

			for (uint32_t i=0; i<NUM_INSTR_DESTINATIONS; i++)
			{
				if (current_instr.destination_memory[i])
				{
					num_dest++;
					num_mem_ops++;
				}
			}
			for (uint32_t i=0; i<NUM_INSTR_SOURCES; i++)
			{
				if (current_instr.source_memory[i])
				{
					num_sour++;
					num_mem_ops++;
				}
			}
			num_instr++;
		}

		if (num_mem_ops)
		{
			if (num_sour)
			{
				paddr = current_instr.source_memory[mem_cnt++];
				paddr = pMapper->translate(paddr);
				optype = 0;
			}
			if (num_dest)
			{
				paddr = current_instr.source_memory[mem_cnt++];
				paddr = pMapper->translate(paddr);
				optype = 1;
			}
			simu_instrs = num_instr;
			simu_addr = paddr;
			simu_ip = current_instr.ip;
			num_instr = 0;
			num_mem_ops--;
			break;			
		}
	}
	mem_fetch = true;

}

