

/*
 * Name: KIM SEONGWOO
 * Student ID#: 2016163055
 */

import java.lang.Math;
import java.util.List;
import java.util.ArrayList;
/*
 * Do NOT import additional packages/classes.
 * If you use (un)intentionally the packages/classes we did not provide,
 * you will get 0 for this assignment.
 */

/*
 * In this assignment, you can (only) additionally refer to the following
 * article:
 * https://en.wikipedia.org/wiki/Hopscotch_hashing
 *
 * Note: We do not allow you to other references (including the article's
 * references) for writing this assignment.
 */

public class Hashtable<K> implements IHashtable<K> {

    IHashFunction<K> h;
    IExtendFunction ex;
    int tableLength;
    int hopLength;
    int numItems;
    List<K> table;

    public Hashtable(
            IHashFunction<K> h,
            IExtendFunction ex,
            int tableLength,
            int hopLength) {
        // constructor
        this.h = h;
        this.ex = ex;
        this.tableLength = tableLength;
        this.hopLength = hopLength;
        numItems = 0;
        table = new ArrayList<K>();
        for(int i = 0; i < tableLength; i++)table.add(null);
        /*
         * IHashFunction<K> h supports the following operation:
         *  + int h.hash(K key, int tableLength): return an integral hash
         *    value of key.
         *
         * IExtendFunction ex supports the following operation:
         *  + boolean ex.checkExtend(int tableLength, int numItems):
         *    return true if the table must be extended for containing
         *    'numItems' items.
         *  + int ex.extendTable(int tableLength): return new table length
         *    for extended table (when the hashtable is "full").
         *  + int ex.extendHop(int tableLength): return new hop length
         *    for extended table (when the hashtable is "full").
         *
         * You MUST use the above methods when you need to extend
         * your hash table. Otherwise, you will get 0.
         */
    }

    @Override
    public void add(K key) {
        /*
         * Input:
         *  + key: A key to be added
         *
         * Job:
         *  Add the key into the hash table.
         *  If the table must be extended or is "full", extend the table and
         *  hop length and retry adding. If the key is already presented
         *  in the hashtable, silently ignore the request.
         *  To decide whether two keys are equal,
         *  you must use _key.equals_ method.
         */
        int target = h.hash(key, tableLength);
        int emptyidx = 0;
        for(int i = target; i < target + tableLength; i++){
            emptyidx = i%tableLength;
            if(table.get(emptyidx) == null)break;
        }
        while((emptyidx - target)%tableLength >= hopLength) {
            boolean flag = false;
            for (int i = hopLength - 1; i > 0; i--) {
                int j = (emptyidx - i) % tableLength;
                if ((emptyidx - h.hash(table.get(j), tableLength)) % tableLength < hopLength) {
                    K temp = table.get(Math.max(j, emptyidx));
                    K temp2 = table.get(Math.min(j, emptyidx));
                    table.remove(Math.max(j, emptyidx));
                    table.remove(Math.min(j, emptyidx));
                    table.add(Math.min(j, emptyidx), temp);
                    table.add(Math.max(j, emptyidx), temp2);
                    emptyidx = j;
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                extand();
                add(key);
                return;
            }
        }
        table.remove(emptyidx);
        table.add(emptyidx, key);
        numItems++;
        if(ex.checkExtend(tableLength, numItems))extand();
    }
    public void extand(){
        Hashtable<K> newtable = new Hashtable<K>(h, ex, ex.extendTable(tableLength), ex.extendHop(tableLength));
        for(int i = 0; i < tableLength; i++){
            if(table.get(i) != null)newtable.add(table.get(i));
        }
        table = newtable.table;
        hopLength = ex.extendHop(tableLength);
        tableLength = ex.extendTable(tableLength);
    }

    @Override
    public void delete(K key) {
        /*
         * Input:
         *  + key: A key to be deleted
         *
         * Job:
         *  Delete the key from the hash table.
         *  If the table does not have key, silently ignore the request.
         *  To decide whether two keys are equal,
         *  you must use _key.equals_ method.
         */
        int target = h.hash(key, tableLength);
        for(int i = 0; i < hopLength; i++){
            if(key.equals(table.get((target + i) % tableLength))){
                table.remove(target + i);
                table.add(target + i, null);
                numItems--;
                return;
            }
        }
    }

    @Override
    public boolean contain(K key) {
        /*
         * Input:
         *  + key: A key to be checked
         *
         * Job:
         *  Return true if the key is in the table; false otherwise.
         *  To decide whether two keys are equal,
         *  you must use _key.equals_ method.
         */
        int target = h.hash(key, tableLength);
        for(int i = 0; i < hopLength; i++){
            if(key.equals(table.get((target + i) % tableLength)))return true;
        }
        return false;
    }

    @Override
    public int size() {
        /*
         * Job:
         *  Return the number of items in the hashtable.
         */
        return numItems;
    }

    @Override
    public int tableLength() {
        /*
         * Job:
         *  Return the length of current hashtable.
         */
        return tableLength;
    }

    @Override
    public int hopLength() {
        /*
         * Job:
         *  Return the current hop length.
         */
        return hopLength;
    }

    @Override
    public List<K> getEntries() {
        /*
         * Job:
         *  Return the entries in the hashtable.
         *  The list index must be the bucket index of the item.
         *  If a bucket has no item, assign null.
         *  Note that you can use ArrayList.
         */
        return table;
    }
}





