

/*
 * Name: KIM SEONGWOO
 * Student ID #: 2016163055
 */

import java.lang.Math;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
/*
 * Do NOT import additional packages/classes.
 * If you (un)intentionally use packages/classes we did not provide,
 * you will get 0.
 */

public class SkipList<K> implements ISkipList<K> {

    public class Node{
        public Node next;
        public Node prev;
        public Node below;
        public K data;
        public int position;// -1 if key is -inf 1 if key is inf else 0
        public Node(K key){
            data = key;
            position = 0;
        }
        public int Compare(Node n){
            if(position == -1 || n.position == 1)return -1;
            else if(position == 1 || n.position == -1)return 1;
            else{
                return comp.compare(data, n.data);
            }
        }
    }

    public class Linkedlist{
        public Node head;
        public Node tail;
        public Linkedlist(){
            head = new Node(null);
            tail = new Node(null);
            head.next = tail;
            tail.prev = head;
            head.position = -1;
            tail.position = 1;
        }
    }

    public Comparator<K> comp;
    public List<Linkedlist> skiplist;
    public ICoin coin;
    int size;
    public SkipList(
            ICoin coin,
            Comparator<K> comp) {
        /*
         * Constructor.
         * ICoin coin provides the following operation:
         *  + coin.toss(): return true if the tossing result is tail
         *
         * You MUST use the coin object to decide on stacking nodes.
         * You also must use comp object to compare two keys.
         *
         * Note that we will check the number of compare calls;
         * if the count is too low or too high (depending on cases),
         * you will fail the case.
         */
        skiplist = new ArrayList<Linkedlist>();
        this.coin = coin;
        this.comp = comp;
        size = 0;
    }


    @Override
    public void add(K key) {
        /*
         * Input:
         *  + key: A key to be added
         *
         * Job:
         *  Insert the key in the skiplist.
         *  If the key is already in this data structure,
         *  silently ignore the request.
         */
        int height = 1;
        while(coin.toss())height++;
        for(int i = skiplist.size(); i <= height; i++){
            skiplist.add(new Linkedlist());
            if(skiplist.size() > 1){
                skiplist.get(skiplist.size() - 1).head.below = skiplist.get(skiplist.size() - 2).head;
                skiplist.get(skiplist.size() - 1).tail.below = skiplist.get(skiplist.size() - 2).tail;
            }
        }
        Node curnode = skiplist.get(skiplist.size() - 1).head;
        Node compare = new Node(key);
        Node upper = null;
        for(int i = skiplist.size() - 1; i >= 0; i--){
            while(compare.Compare(curnode.next) > 0){
                curnode = curnode.next;
                if(compare.Compare(curnode.next) == 0)return;
            }
            if(i < height){
                Node newnode = new Node(key);
                newnode.next = curnode.next;
                newnode.prev = curnode;
                curnode.next.prev = newnode;
                curnode.next = newnode;
                if(upper != null)upper.below = newnode;
                upper = newnode;
            }
            curnode = curnode.below;
        }
        size++;
    }

    @Override
    public void delete(K key) {
        /*
         * Input:
         *  + key: A key to be deleted.
         *
         * Job:
         *  Delete the key from the structure.
         *  If the key is NOT in the structure, ignore the request.
         */
        Node curnode = skiplist.get(skiplist.size() - 1).head;
        Node compare = new Node(key);
        while(true){
            while(compare.Compare(curnode.next) >= 0)curnode = curnode.next;
            if(curnode.data != key){
                if(curnode.below == null)return;
                curnode = curnode.below;
            }
            else break;
        }
        while(true){
            curnode.prev.next = curnode.next;
            curnode.next.prev = curnode.prev;
            if(curnode.below == null)break;
            curnode = curnode.below;
        }
        size--;
    }

    @Override
    public boolean contain(K key) {
        /*
         * Input:
         *  + key: A key to be checked.
         *
         * Job:
         *  Return true if the given key is in the structure; false otherwise.
         */
        Node curnode = skiplist.get(skiplist.size() - 1).head;
        Node compare = new Node(key);
        while(true){
            while(compare.Compare(curnode.next) >= 0)curnode = curnode.next;
            if(curnode.data != key){
                if(curnode.below == null)return false;
                curnode = curnode.below;
            }
            else break;
        }
        return true;
    }

    @Override
    public List<K> getEntries() {
        /*
         * Job:
         *  Return the entries in the skiplist.
         *  The list items must be in sorted order.
         *  Note that you can use ArrayList.
         */
        List<K> res = new ArrayList<K>();
        for(Node curnode = skiplist.get(0).head; curnode != skiplist.get(0).tail; curnode = curnode.next){
            if(curnode == skiplist.get(0).head)continue;
            res.add(curnode.data);
        }
        return res;
    }

    @Override
    public int size() {
        /*
         * Job:
         *  Return the number of items in the structure.
         */
        return size;
    }

    @Override
    public boolean isEmpty() { return size() == 0; }
}



