/*
 * Name: Kim Seongwoo
 * Student ID #: 2016163055
 */

/* 
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public class Sorter implements ISorter {
	public Sorter() { ; }

	@Override
	public int[] ascending(int[] a) {
		/*
		 * Input:
		 *  - an integer array A
		 *
		 * Output: a sorted array A in *ascending* order.
		 */
		int t = 0;
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j < a.length-1; j++){
				if(a[j] > a[j+1]){
				t = a[j];
				a[j] = a[i];
				a[i] = t;
				}
			}
		}
		return a;

	}
	public void ascsort(int[] a, int x, int y){//mergesort
		if(x == y)return;// when size is 1
		int z = (x+y)/2;
		ascsort(a,x,z);
		ascsort(a,z+1,y);
		ascmerge(a,x,y,z);
	}
    	public void ascmerge(int[] a, int x, int y, int z){
        		int[] b = new int[y-x+1];
        		int i = x;
        		int j = z+1;
        		boolean iend = false;
        		boolean jend = false;
        		for(int k = 0; k <= y-x; k++){
            		if(!jend && (iend || a[i] > a[j])){
                		b[k] = a[j];
                		j++;
                		if(j == y+1)jend = true;
            		}
            		else{
                			b[k] = a[i];
                			i++;
                			if(i == z+1)iend = true;
            		}
        		}
        		for(int k = 0; k <= y-x; k++) {
            		a[x+k] = b[k];
        		}
    	}
	
	@Override
	public int[] descending(int[] a) {
		/*
		 * Input:
		 *  - an integer array A
		 *
		 * Output: a sorted array A in *descending* order.
		 */
		return reverse(ascending(a));
	}
		public int[] reverse(int[] a){
		int[] b = new int[a.length];
		for(int i = 0; i < a.length; i++){
			b[i] = a[a.length-i-1];
		}
		return b;
	}
}
