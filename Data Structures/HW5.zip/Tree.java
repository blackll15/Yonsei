/*
 * Name:KIM SEONGWOO
 * Student ID #: 2016163055
 */

import java.lang.Math;
import java.util.Comparator;
/*
 * Do NOT import additional packages/classes.
 * If you (un)intentionally use packages/classes we did not provide,
 * you will get 0.
 */

public class Tree<K> implements ITree<K> {

    TreeNode<K> root;
    Comparator<K> comp;
    int size;
    public Tree(Comparator<K> comp) {
        /*
         * Constructor.
         *
         * Note that we will check the number of compare calls;
         * if the count is too low or too high (depending on cases),
         * you will fail the case.
         */
        root = null;
        this.comp = comp;
        size = 0;
    }
    @Override
    public TreeNode<K> root()
            throws IllegalStateException {
        /*
         * Return the root node.
         * If there is no root, raise an IllegalStateException.
         */
        if(isEmpty())throw new IllegalStateException();
        return root;
    }

    @Override
    public TreeNode<K> insert(K key) {
        /*
         * Insert the given key at the appropriate node
         * with correct position and return the node.
         * You need to handle the cases of 'overflow' and
         * perform a split operation.
         * Note that you do not need to consider the case of inserting
         * the key that is already in the tree. As stated in the
         * guideline, we will only insert the key that is not in the
         * tree.
         */
        if(size == 0){
            TreeNode<K> newnode = new TreeNode<K>();
            newnode.insertKey(0, key);
            root = newnode;
            size++;
            return newnode;
        }
        TreeNode<K> tonode;
        for(tonode = root; tonode.numChildren() != 0;){
            int j = 0;
            for(int i = 0; i < tonode.numKeys(); i++){
                if(comp.compare(key, tonode.getKey(i)) > 0)j++;
            }
            if(tonode.numChildren() != 0)tonode = tonode.getChild(j);
        }
        if(tonode.numKeys() < 3){
            insertinsideNode(key, tonode);
            size++;
            return tonode;
        }
        size++;
        return insertNode(key, null, tonode);
    }

    public TreeNode<K> insertNode(K key, TreeNode<K> child, TreeNode<K> tonode){

        if(child != null)child.setParent(tonode);
        if(tonode.numKeys() < 3){
            insertinsideNode(key , tonode);
            insertchildNode(child, tonode);
            return tonode;
        }
        else{
            K midkey = tonode.getKey(1);
            insertinsideNode(key, tonode);
            insertchildNode(child, tonode);
            int mididx = 1;
            if(tonode.getKey(2).equals(midkey))mididx = 2;
            TreeNode<K> right = new TreeNode<K>();
            for(int i = 0; i < 4 - mididx; i++){
                if(tonode.numChildren() != 0){
                    right.insertChild(i, tonode.getChild(mididx + 1));
                    tonode.getChild(mididx + 1).setParent(right);
                    tonode.removeChild(mididx + 1);
                }
                if(i != 0){
                    right.insertKey(i - 1, tonode.getKey(mididx + 1));
                    tonode.removeKey(mididx + 1);
                }
            }
            tonode.removeKey(mididx);
            if(tonode == root){
                TreeNode<K> newroot = new TreeNode<K>();
                root = newroot;
                root.insertKey(0, midkey);
                root.insertChild(0, tonode);
                root.insertChild(1, right);
                tonode.setParent(root);
                right.setParent(root);
            }
            else{
                insertNode(midkey, right, tonode.getParent());
            }
            if(mididx == 1)return right;
            else return tonode;
        }
    }
    public void printkey(TreeNode<K> node){
        System.out.print("{");
        for(int i = 0; i < node.numKeys(); i++){
            System.out.print(node.getKey(i));
            System.out.print(",");
        }
        System.out.print("}");
    }
    public void printsubtree(TreeNode<K> node){
        printkey(node);
        for(int i = 0; i < node.numChildren(); i++)printsubtree(node.getChild(i));
    }

    public void insertinsideNode(K key, TreeNode<K> node){
        int j = 0;
        for(int i = 0; i < node.numKeys(); i++){
            if(comp.compare(key, node.getKey(i)) > 0)j++;
        }
        node.insertKey(j, key);
    }
    public void insertchildNode(TreeNode<K> child, TreeNode<K> node){
        if(child == null)return;
        int j = 0;
        for(int i = 0; i < node.numKeys(); i++){
            if(comp.compare(child.getKey(0), node.getKey(i)) > 0)j++;
        }
        node.insertChild(j, child);
        child.setParent(node);
    }

    @Override
    public void delete(K key) {
        /*
         * Find the node with a given key and delete the key.
         * You need to handle the cases of 'underflow' and
         * perform a fusion operation.
         * If there is no "key" in the tree, please ignore it.
         */
        if(size == 0)return;
	if(root.numChildren() == 2 && root.getChild(0).numKeys() == 1 && root.getChild(1).numKeys() == 1 ){
            merge(root.getChild(0), root.getChild(1), root);
        }

        TreeNode<K> deletenode = new TreeNode<K>();
        deletenode = find(key, root);
        if(deletenode == null)return;
        if(size == 1 && root.getKey(0).equals(key)){
            root.removeKey(0);
            root = null;
            size--;
        }
        else if(deletenode.numChildren() == 0){//leaf node case
            if(deletenode.numKeys() > 1){
                deleteinsideNode(key, deletenode);
            }
            else{// underflow
                TreeNode<K> parent = deletenode.getParent();
                int sibling_has_two = -1;
                int deletenodeidx = -1;
                for(int i = 0; i < parent.numChildren(); i++){
                    if(parent.getChild(i) == deletenode)deletenodeidx = i;
                }
                for(int i = 0; i < parent.numChildren(); i++){
                    if(parent.getChild(i).numKeys() > 1 &&( i == deletenodeidx + 1 || i == deletenodeidx - 1)){
                        sibling_has_two = i;
                    }
                }
                if(sibling_has_two != -1){//neighbor has two node
                    TreeNode<K> neighbor = parent.getChild(sibling_has_two);
                    K up;
                    if(sibling_has_two == deletenodeidx - 1){
                        up = neighbor.getKey(neighbor.numKeys() - 1);
                        insertinsideNode(up , parent);
                        neighbor.removeKey(neighbor.numKeys() - 1);
                        int upidx = -1;
                        for(int i = 0; i < parent.numKeys(); i++){
                            if(parent.getKey(i) == up)upidx = i;
                        }
                        insertinsideNode(parent.getKey(upidx + 1), deletenode);
                        deleteinsideNode(key, deletenode);
                        parent.removeKey(upidx + 1);
                    }
                    else{// get data from right neighbor
                        up = neighbor.getKey(0);
                        insertinsideNode(up, parent);
                        neighbor.removeKey(0);
                        int upidx = -1;
                        for(int i = 0; i < parent.numKeys(); i++){
                            if(parent.getKey(i) == up)upidx = i;
                        }
                        insertinsideNode(parent.getKey(upidx - 1), deletenode);
                        deleteinsideNode(key, deletenode);
                        parent.removeKey(upidx - 1);
                    }

                }
                else{
                    int idx = -1;
                    for(int i = 0; i < parent.numChildren(); i++){
                        if( i == deletenodeidx + 1 || i == deletenodeidx - 1){
                            idx = i;
                        }
                    }

                    if(idx < deletenodeidx){
                        deleteinsideNode(key, merge(parent.getChild(idx), parent.getChild(deletenodeidx), parent));
                    }
                    else{
                        deleteinsideNode(key, merge(parent.getChild(deletenodeidx), parent.getChild(idx), parent));
                    }
                }
            }
        }
        else{//internal node case
            int deletekeyidx = -1;
            for(int i = 0; i < deletenode.numKeys(); i++){
                if(deletenode.getKey(i).equals(key))deletekeyidx = i;
            }
            int childidx = -1;
            for(int i = deletenode.numChildren() - 1; i >= 0; i--){
                if(deletenode.getChild(i).numKeys() > 1 && (i == deletekeyidx || i == deletekeyidx + 1))childidx = i;
            }
            if(childidx == -1){
                deleteinsideNode(key, merge(deletenode.getChild(deletekeyidx), deletenode.getChild(deletekeyidx + 1), deletenode));
            }
            else{//neighbor child has two key
                TreeNode<K> child = deletenode.getChild(childidx);
                K tmp;
                if(childidx == deletekeyidx){
                    tmp = child.getKey(child.numKeys() - 1);
                    child.removeKey(child.numKeys() - 1);
                }
                else{
                    tmp = child.getKey(0);
                    child.removeKey(0);
                }
                deleteinsideNode(key, deletenode);
                insertinsideNode(tmp, deletenode);
            }
        }
    }
    public TreeNode<K> merge(TreeNode<K> left, TreeNode<K> right, TreeNode<K> parent){
        TreeNode<K> leftleft = null;
        TreeNode<K> leftright = null;
        TreeNode<K> rightleft = null;
        TreeNode<K> rightright = null;
        if(left.numChildren() == 2){
            leftleft = left.getChild(0);
            leftright = left.getChild(1);
        }
        if(right.numChildren() == 2){
            rightleft = right.getChild(0);
            rightright = right.getChild(1);
        }
        if(parent.numKeys() == 1){
            parent.insertKey(0, left.getKey(0));
            parent.insertKey(2, right.getKey(0));
            parent.removeChild(0);
            parent.removeChild(0);
            left.removeKey(0);
            right.removeKey(0);
            insertchildNode(leftleft, parent);
            insertchildNode(leftright, parent);
            insertchildNode(rightleft, parent);
            insertchildNode(rightright, parent);
            return parent;
        }
        else{
            int mididx = -1;
            for(int i = 0; i < parent.numKeys(); i++){
                if(comp.compare(right.getKey(0), parent.getKey(i)) > 0)mididx = i;
            }
            left.insertKey(1, parent.getKey(mididx));
            left.insertKey(2, right.getKey(0));
            parent.removeChild(mididx + 1);
            parent.removeKey(mididx);
            right.removeKey(0);
            if(right.numChildren() != 0){
                right.removeChild(0);
                right.removeChild(0);
            }
            insertchildNode(rightleft, left);
            insertchildNode(rightright, left);
            return left;
        }
    }
    public void deleteinsideNode(K key, TreeNode<K> deletenode) {
        for (int i = 0; i < deletenode.numKeys(); i++) {
            if (comp.compare(key, deletenode.getKey(i)) == 0) {
                deletenode.removeKey(i);
                size--;
                return;
            }
        }
    }

        @Override
        public boolean search(K key) {
        /*
         * Find a node with a given key and return true if you can find it.
         * Return false if you cannot.
         */
        return find(key, root) != null;
    }

    public TreeNode<K> find(K key, TreeNode<K> curnode){
        if(curnode == null)return null;
        int j = 0;
        for(int i = 0; i < curnode.numKeys(); i++){
            if(key.equals(curnode.getKey(i)))return curnode;
            if(comp.compare(key, curnode.getKey(i)) > 0)j++;
        }
        if(curnode.numChildren() == 0)return null;
        return find(key, curnode.getChild(j));
    }

    @Override
    public int size() {
        /*
         * Return the number of keys in the tree.
         */
        return size;
    }

    @Override
    public boolean isEmpty() {
        /*
         * Return whether the tree is empty or not.
         */
        return size == 0;
    }
}
