/*
 * Name: Kim Seongwoo
 * Student ID #: 2016163055
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

/* Double-ended queue */
public final class Deque<E> implements IDeque<E> {
    /*
     * Use some variables for your implementation.
     */
    List<E> deque;

    public Deque() {
        /*
         * Constructor
         * This function is an initializer for this class.
         */
        deque = new List<E>();
    }

    @Override
    public void insertFirst(E item) {
        /*
         * Function input:
         *  item: an item to be inserted.
         *
         * Job:
         *  Insert the given item before the first item of this deque.
         *  If this deque is empty, use this item as the first item.
         */
        deque.AddFront(new ListItem<E>(item, null));
    }

    @Override
    public void insertLast(E item) {
        /*
         * Function input:
         *  item: an item to be inserted.
         *
         * Job:
         *  Insert the given item after the last item of this deque.
         *  If this deque is empty, use this item as the last item.
         */
        deque.Insert(deque.length, new ListItem<E>(item, null));
    }

    @Override
    public void deleteFirst()
            throws IllegalStateException {
        /*
         * Function input: Nothing
         *
         * Job:
         *  Delete the first item of the deque.
         *
         *  If there is no item, raise an IllegalStateException.
         *  You do not have to specify its message.
         */
        if(deque.IsEmpty())throw new IllegalStateException();
        deque.DeleteFront();
    }

    @Override
    public void deleteLast()
            throws IllegalStateException {
        /*
         * Function input: Nothing
         *
         * Job:
         *  Delete the last item of the deque.
         *
         *  If there is no item, raise an IllegalStateException.
         *  You do not have to specify its message.
         */
        if(deque.IsEmpty())throw new IllegalStateException();
        deque.Delete(deque.length - 1);
    }

    @Override
    public E first()
            throws IllegalStateException {
        /*
         * Function input: Nothing
         *
         * Job:
         *  Return the first item.
         *
         *  If there is no item, raise an IllegalStateException.
         *  You do not have to specify its message.
         */
        if(deque.IsEmpty())throw new IllegalStateException();
        return deque.Head().data;
    }

    @Override
    public E last()
            throws IllegalStateException {
        /*
         * Function input: Nothing
         *
         * Job:
         *  Return the last item.
         *
         *  If there is no item, raise an IllegalStateException.
         *  You do not have to specify its message.
         */
        if(deque.IsEmpty())throw new IllegalStateException();
        return deque.end.data;
    }

    @Override
    public int size() {
        /*
         * Function input: Nothing
         *
         * Job:
         *  Return the number of items in the deque.
         */
        return deque.Length();
    }

    @Override
    public boolean isEmpty() {
        /* You do not have to edit this function. */
        return size() == 0;
    }
    public class ListItem<E> {

        int position;
        E data;
        ListItem next;

        public ListItem(E x, ListItem n) {
            data = x;
            next = n;
        }
    }
    public class List<E> {

        ListItem<E> first;//first item reference
        ListItem<E> end;//last item reference
        int length;
        // default constructor
        public List() {
            first = null;
            end = null;
            length = 0;
        }
        // returns true if the list is empty, false otherwise
        public boolean IsEmpty() {
            return length == 0;
        }
        // returns the length of the list.
        public int Length() {
            return length;
        }
        // retrieves the item at given position from the list.
        //If the operation is successful, item will have the item at that position, otherwise return null.
        //The list is unaffected by this operation.
        public ListItem<E> Retrieve(int position) {
            if(length > position && position >= 0) {
                ListItem<E> cur;
                for(cur = first; position != 0; position--) {//repeats position times
                    cur = cur.next;
                }
                return cur;
            }
            else return null;
        }
        // returns the first item of the list.
        ListItem<E> Head() {
            return first;
        }
        // inserts the item at the given position.
        //It returns the status of the operation; SUCCESS or FAILURE.
        public boolean Insert(int newPosition, ListItem<E> newItem){
            if(length < newPosition || 0 > newPosition || newItem.equals(null)) {
                return false;//position is wrong or item is null
            }
            if (IsEmpty()){//list is empty
                first = newItem;
                end = newItem;
            }
            else if(newPosition == 0) {//add at front
                newItem.next = first;
                first = newItem;
            }
            else if(newPosition == length) {//add at end
                end.next = newItem;
                end = newItem;
            }
            else {//add middle of list
                ListItem cur = Retrieve(newPosition-1);
                newItem.next = cur.next;
                cur.next = newItem;
            }
            length++;
            return true;
        }
        // deletes the item at the given position.
        public boolean Delete(int position) {
            if(0 <= position && position < length) {
                if(length == 1) {// when there is only one item
                    first = null;
                    end = null;
                }
                else if(position == 0) { //delete front
                    first = first.next;
                }
                else if(position == length - 1) {// delete end
                    end = Retrieve(length - 2);
                    end.next = null;
                }else {//delete middle of list
                    ListItem<E> tmp = Retrieve(position).next;
                    Retrieve(position-1).next = tmp;
                }
                length--;
                return true;
            }
            return false;
        }
        // adds the item at the front of the list.
        public boolean AddFront(ListItem<E> newItem) {
            return Insert(0, newItem);
        }
        public boolean DeleteFront() {
            return Delete(0);
        }
    }
}

