/*
 * Name: Kim Seongwoo
 * Student ID #: 2016163055
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public class PostfixCalc implements ICalc {

    /* Use some variables for your implementation. */

    public PostfixCalc() {
        /*
         * Constructor
         */
    }

    @Override
    public int evaluate(String expression) {
        /*
         * Function input:
         *  + expression: A postfix expression.
         *
         * Job:
         *  Return the value of the given expression.
         *
         * The postfix expression is a valid expression with
         * length of at least 1.
         * There are +(addition), -(subtraction) and *(multiplication)
         * operators and only non-negative integers, seperated with
         * a single space symbol.
         */
        //5 10 4 * +
        String[] line = expression.split(" ");
        Deque<Integer> q = new Deque<Integer>();
        for(int i = 0; i < line.length; i++){
            String s = line[i];
            if(s.equals("+") || s.equals("-") || s.equals("*")){
                int a, b, r = 0;
                a = q.first();
                q.deleteFirst();
                b = q.first();
                q.deleteFirst();
                switch (s){
                    case "+":
                        r = b + a;
                        break;
                    case "-":
                        r = b - a;
                        break;
                    case "*":
                        r = b * a;
                        break;
                }
                q.insertFirst(r);
            }
            else {
                q.insertFirst(Integer.parseInt(s));
            }
        }
        return q.first();
    }
}
