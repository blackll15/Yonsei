/*
 * Name: Kim Seongwoo
 * Student ID#: 2016163055
 */

/*
 * Do NOT use any external packages/classes.
 * If you (un)intentionally use them we did not provide,
 * you will get 0.
 * Also do NOT use auto-import function on IDEs.
 * If the import statements change, you will also get 0.
 */

import java.util.List;
import java.util.ArrayList;

public final class Tree<E> implements ITree<E>{

    TreeNode<E> root;
    int ary;
    int size;

    public Tree(int arity) {
        /*
         * Input:
         *  + arity: max number of node's children. always positive.
         */
        ary = arity;
        size = 0;
        root = null;
    }

    @Override
    public TreeNode<E> root()
            throws IllegalStateException {
        /*
         * Return the root node.
         * If there is no root, raise an IllegalStateException.
         */
        if(root == null)throw new IllegalStateException();
        return root;
    }

    @Override
    public int arity() {
        /*
         * Return the max number of children its node can have
         */
        return ary;
    }

    @Override
    public int size() {
        /*
         * Return the number of nodes in this tree.
         */
        return size;
    }

    @Override
    public boolean isEmpty() {
        /*
         * Return true if this tree is empty.
         */
        return size == 0;
    }

    @Override
    public int height()
            throws IllegalStateException {
        /*
         * Return height of this tree.
         * If there are no nodes in this tree,
         * raise an IllegalStateException.
         */
        if(isEmpty())throw new IllegalStateException();
        return getheight(root);
    }

    public int getheight(TreeNode<E> n){
        int height = 0;
        if(n.numChildren() == 0)return 0;
        for(int k = 0; k < n.numChildren(); k++){
            if(height < getheight(n.getChild(k)))height = getheight(n.getChild(k));
        }
        return ++height;
    }

    @Override
    public TreeNode<E> add(E item) {
        /*
         * Insert the given node at the *end* of this tree and
         * return THE inserted NODE.
         * *End* means that the rightmost possible slot of
         * lowest depth of this tree.
         */
        TreeNode<E> newnode = new TreeNode<E>(ary, item);
        if(isEmpty()){
            root = newnode;
            size++;
            return newnode;
        }
        List<TreeNode<E>> L = new ArrayList<TreeNode<E>>();
        L.add(root);
        int depth = 0;
        while(true){
            if(L.size() < java.lang.Math.pow(ary, depth))break;
            for(int i = 0; i < java.lang.Math.pow(ary, depth); i++){
                for(int k = 0; k < L.get(0).numChildren(); k++)L.add(L.get(0).getChild(k));
                L.remove(0);
            }
            depth++;
        }
        L.clear();
        L.add(root);
        for(int i = 0; i < depth - 1; i++){
            for(int k = 0; k < L.get(0).numChildren(); k++)L.add(L.get(0).getChild(k));
            L.remove(0);
        }
        for(int i = L.size() - 1; i >= 0; i--){
            if(L.get(i).numChildren() < ary){
                L.get(i).insertChild(L.get(i).numChildren(), newnode);
                newnode.setParent(L.get(i));
                size++;
                break;
            }
        }
        return newnode;
    }

    @Override
    public void detach(TreeNode<E> node)
            throws IllegalArgumentException {
        /*
         * Detach the given node (and its descendants) from this tree.
         * if the node is not in this tree,
         * raise an IllegalArgumentException.
         */
        if(isEmpty())throw new IllegalArgumentException();
        if(root == node){
            root = null;
            size = 0;
            return;
        }
        List<TreeNode<E>> L = new ArrayList<TreeNode<E>>();
        L.add(root);
        while(!L.isEmpty()) {
            int s = L.size();
            for (int i = 0; i < s; i++) {
                for (int k = 0; k < L.get(0).numChildren(); k++) {
                    L.add(L.get(0).getChild(k));
                    if(L.get(0).getChild(k) == node){
                        for(int j = 0; j < node.getParent().numChildren(); j++){
                            if(node.getParent().getChild(j) == node){
                                node.getParent().removeChild(j);
                                List<E> seq = new ArrayList<E>();
                                previsit(seq, node);
                                size -= seq.size();
                                break;
                            }
                        }
                        return;
                    }
                }
                L.remove(0);
            }
        }
        throw new IllegalArgumentException();
    }

    @Override
    public List<E> preorder() {
        /*
         * Return the sequence of items visited by preorder traversal.
         * If there are no nodes, return an empty list, NOT NULL.
         */
        List<E> seq = new ArrayList<>();
        if(isEmpty())return seq;
        previsit(seq, root);
        return seq;
    }

    public void previsit(List<E> L, TreeNode<E> e){
        L.add(L.size(), e.getValue());
        for(int k = 0; k < e.numChildren(); k++){
            previsit(L, e.getChild(k));
        }
    }

    @Override
    public List<E> postorder() {
        /*
         * Return the sequence of items visited by postorder traversal.
         * If there are no nodes, return an empty list, NOT NULL.
         */
        List<E> seq = new ArrayList<E>();
        if(isEmpty())return seq;
        postvisit(seq, root);
        return seq;
    }
    public void postvisit(List<E> L, TreeNode<E> e){
        for(int k = 0; k < e.numChildren(); k++){
            postvisit(L, e.getChild(k));
        }
        L.add(L.size(), e.getValue());
    }
}


