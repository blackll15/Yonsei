/*
 * Name: Kim SeongWoo
 * Student ID#: 2016163055
 */

/*
 * Do NOT use any external packages/classes.
 * If you (un)intentionally use them we did not provide,
 * you will get 0.
 * Also do NOT use auto-import function on IDEs.
 * If the import statements change, you will also get 0.
 */

import java.util.Comparator;

/*
 * Refer to the following document for Comparator:
 * https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html
 */

public final class StreamMin<E> implements IStreamMin<E> {

    public Tree<E> tree;
    public Comparator<E> comp;
    // You need to implement StreamMin using this.

    public StreamMin(Comparator<E> comp) {
        // use comp to compare two E values.
        tree = new Tree<E>(2);
        this.comp = comp;
    }

    public void change_pos(TreeNode<E> a, TreeNode<E> b){//takes constant time O(1)
        E temp = a.getValue();
        a.setValue(b.getValue());
        b.setValue(temp);

    }

    public void up_heapify(TreeNode<E> n){ // takes time O(hight ~= logn)
        if(n == tree.root())return;
        else if(comp.compare(n.getParent().getValue(), n.getValue()) > 0){
            change_pos(n, n.getParent());
            up_heapify(n.getParent());
        }
    }

    public void down_heapify(TreeNode<E> n){ // takes time O(hight ~= logn)
        if(n.numChildren() == 0)return;
        else if(n.numChildren() == 1){
            if(comp.compare(n.getValue(), n.getChild(0).getValue()) > 0){
                change_pos(n, n.getChild(0));
                down_heapify(n.getChild(0));
            }
        }
        else{
            E left = n.getChild(0).getValue();
            E right = n.getChild(1).getValue();
            E mine = n.getValue();
            if(comp.compare(mine, left) > 0){
                if(comp.compare(left, right) > 0){
                    change_pos(n, n.getChild(1));
                    down_heapify(n.getChild(1));
                }
                else{
                    change_pos(n, n.getChild(0));
                    down_heapify(n.getChild(0));
                }
            }
            else if(comp.compare(mine, right) > 0){
                change_pos(n,n.getChild(1));
                down_heapify(n.getChild(1));
            }
        }
    }

    @Override
    public void add(E e) {
        /*
         * Input:
         *  + e: An item.
         *
         * Add the item in the data structure.
         */
        int target = tree.size() + 1;
        TreeNode<E> newnode = new TreeNode<E>(2, e);
        if(isEmpty()){
            tree.root = newnode;
            tree.size++;
            return;
        }
        int arraysize = 0;
        for(int i = 0; i <= target + 1; i++){
            if(java.lang.Math.pow(2,i) > target){
                arraysize = i - 1;
                break;
            }
        }

        int[] navi = new int[arraysize];
        for(int i = arraysize - 1; i >= 0; i--){
            navi[i] = (target % 2 == 0) ? 0: 1;
            target = target/2;
        }


        TreeNode<E> curnode = tree.root;
        for(int i = 0; i < navi.length - 1; i++){
            curnode = curnode.getChild(navi[i]);
        }
        curnode.insertChild(navi[navi.length-1],newnode);
        newnode.setParent(curnode);
        tree.size++;
        up_heapify(newnode);
    }

    @Override
    public E findMin()
            throws IllegalStateException {
        /*
         * Return the smallest (with respect to the comparator)
         * from the items this structure has.
         * If this has no item at the time of method call,
         * raise an IllegalStateException.
         */
        if(isEmpty())throw new IllegalStateException();
        return tree.root().getValue();
    }

    @Override
    public E extractMin()
            throws IllegalStateException {
        /*
         * Return the smallest (with respect to the comparator)
         * from the items this structure has.
         * The smallest one must be removed from this structure.
         * If this has no item at the time of method call,
         * raise an IllegalStateException.
         */
        if(isEmpty())throw new IllegalStateException();
        E result = tree.root.getValue();
        if(tree.size() == 1){
            tree.root = null;
            tree.size = 0;
            return result;
        }
        int target = tree.size();
        int arraysize = 0;
        for(int i = 0; i <= target + 1; i++){
            if(java.lang.Math.pow(2,i) > target){
                arraysize = i - 1;
                break;
            }
        }
        int[] navi = new int[arraysize];
        for(int i = arraysize - 1; i >= 0; i--){
            navi[i] = (target % 2 == 0) ? 0: 1;
            target = target/2;
        }
        TreeNode<E> curnode = tree.root;
        for(int i = 0; i < navi.length; i++){
            curnode = curnode.getChild(navi[i]);
        }
        TreeNode<E> deletenode = curnode;
        change_pos(curnode, tree.root);
        for(int j = 0; j < deletenode.getParent().numChildren(); j++){
            if(deletenode.getParent().getChild(j) == deletenode){
                deletenode.getParent().removeChild(j);
                tree.size--;
                break;
            }
        }
        deletenode.setParent(null);
        down_heapify(tree.root);

        return result;
    }

    @Override
    public void reset() {
        /*
         * Remove all items from this structure.
         */
        if(!isEmpty())tree.detach(tree.root());
    }

    @Override
    public int size() {
        /*
         * Return the number of items this structure has.
         */

        return tree.size();
    }

    @Override
    public boolean isEmpty() {
        /*
         * Return true if this structure is empty.
         */
        return tree.isEmpty();
    }
}





