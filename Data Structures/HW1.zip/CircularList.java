/*
* Name: Kim Seongwoo
* Student ID #: 2016163055
*/

/*
* Do NOT import any additional packages/classes.
* If you (un)intentionally use some additional packages/classes we did not
* provide, you may receive a 0 for the homework.
*/

/* Doubly circular linked list */
public final class CircularList implements ICircularList {
    /*
    * Add some variables you use.
    */
    private Node head;
    private int size;

    public CircularList() {
        /*
        * Constructor
        * This function is an initializer for this class.
        */
        head = null;
        size = 0;
    }

    @Override
    public void insert(int item) {
        /*
        * Function input:
        *  + item: An integer to be inserted.
        *
        * Job:
        *  Insert the given integer between the head and before the head.
        *  The head must not be changed.
        *  If there is no head, use the integer as a new head.
        */
    Node newnode = new Node(item);
		if(isEmpty()){
			head = newnode;
			head.prev = head;
			head.next = head;
		}
		else{
			head.prev.next = newnode;
			newnode.next = head;
			newnode.prev = head.prev;
			head.prev = newnode;
		}
		size++;
	}

    @Override
    public void delete()
            throws IllegalStateException {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Delete the previous node of the head node.
        *
        *  If there is no head, raise an IllegalStateException.
        *  You do not have to specify its message.
        */
 	         if(isEmpty())throw new IllegalStateException();
		else if(size == 1){
			head = null;
		}
		else{
			head.prev.prev.next = head;
			head.prev = head.prev.prev;
		}
		size--;
	}

    @Override
    public Node getHead() throws IllegalStateException {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Return the head node.
        *
        *  If there is no head, raise an IllegalStateException.
        *  You do not have to specify its message.
        */
        if(isEmpty())throw new IllegalStateException();
		return head;
}

    @Override
    public void rotateForward() throws IllegalStateException {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Make the head point its next.
        *
        *  If there is no head, raise an IllegalStateException.
        *  You do not have to specify its message.
        */
    if(isEmpty())throw new IllegalStateException();
    head = head.next;
}

    @Override
    public void rotateBackward() throws IllegalStateException {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Make the head point its previous.
        *
        *  If there is no tail, raise an IllegalStateException.
        *  You do not have to specify its message.
        */
    if(isEmpty())throw new IllegalStateException();
		head = head.prev;
}

    @Override
    public int size() {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Return the number of items in this list.
        */
        return size;
    }

    @Override
    public boolean isEmpty() {
        /* You do not have to edit this function. */
        return size() == 0;
    }
}
