/*
 * Name: Kim Seongwoo
 * Student ID #: 2016163055
 */

/*
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public final class NQueenSolver implements INQueenSolver {
    @Override
    public Chessboard solve(Chessboard chessboard) {
        /*
         * Function input:
         *  + chessboard: A chess board with some queens.
         *
         * Job:
         *  Return an N-Queen solution on the given chessboard.
         *  If there is no solution, return an empty board of the same size.
         */
         int queensleft = chessboard.size()-queennum(chessboard);
         if(goodboard(chessboard))return emptyboard(chessboard);
         Chessboard output = dfs(chessboard,queensleft);
         if(output.equals(null)) return emptyboard(chessboard);
         else return output;

    }
    public Chessboard dfs(Chessboard chessboard, int queensleft){
        if(queensleft == 0 && goodboard(chessboard))return chessboard;
        Chessboard newboard = null;
        for (int i = 0; i < chessboard.size(); i++) {
            for (int j = 0; j < chessboard.size(); j++) {
                if(chessboard.getCell(i, j) == Chessboard.CellState.EMPTY && placeable(i,j,chessboard))
                    newboard = chessboard.clone();
                    newboard.setCell(i,j,Chessboard.CellState.QUEEN);
                    if(!dfs(newboard, queensleft-1).equals(null))return dfs(newboard,queensleft-1);
            }
        }
        return null;
    }
    public boolean placeable(int i, int j, Chessboard chessboard){
        for(int k = 0; k < chessboard.size(); k++){
            if(chessboard.getCell(k,j) == Chessboard.CellState.QUEEN)return false;
            else if(chessboard.getCell(i,k) == Chessboard.CellState.QUEEN) return false;
            if(inboard(i+k,j+k,chessboard.size())&&chessboard.getCell(i+k,j+k) == Chessboard.CellState.QUEEN)return false;
            if(inboard(i-k,j+k,chessboard.size())&&chessboard.getCell(i-k,j+k) == Chessboard.CellState.QUEEN)return false;
            if(inboard(i+k,j-k,chessboard.size())&&chessboard.getCell(i+k,j-k) == Chessboard.CellState.QUEEN)return false;
            if(inboard(i-k,j-k,chessboard.size())&&chessboard.getCell(i-k,j-k) == Chessboard.CellState.QUEEN)return false;
        }
        return true;
    }
    public Chessboard emptyboard(Chessboard chessboard) {
        for (int i = 0; i < chessboard.size(); i++) {
            for (int j = 0; j < chessboard.size(); j++) {
                chessboard.setCell(i, j, Chessboard.CellState.EMPTY);
            }
        }
        return chessboard;
    }
    public boolean goodboard(Chessboard chessboard){
        Chessboard newboard = new Chessboard(chessboard.size());
        for (int i = 0; i < chessboard.size(); i++) {
            for (int j = 0; j < chessboard.size(); j++) {
                if (chessboard.getCell(i, j) == Chessboard.CellState.QUEEN){
                    if(placeable(i,j,newboard))newboard.setCell(i,j,Chessboard.CellState.QUEEN);
                    else return false;
                }
            }
        }
        return true;
    }
    public int queennum(Chessboard chessboard){
        int cnt = 0;
            for (int i = 0; i < chessboard.size(); i++) {
                for (int j = 0; j < chessboard.size(); j++) {
                    if (chessboard.getCell(i, j) == Chessboard.CellState.QUEEN)cnt++;
                }
            }
        return cnt;
    }
    public boolean inboard(int i, int j, int size){
        return size > i && i >=0 && size > j && j >= 0;
    }
}
