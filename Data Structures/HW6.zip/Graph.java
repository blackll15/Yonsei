
/*
 * Name: SEONGWOO KIM
 * Student ID: 2016163055
 */

import java.util.List;
import java.util.ArrayList;

/*
 * Do NOT import additional packages/classes.
 * If you (un)intentionally use packages/classes we did not provide,
 * you will get 0.
 */

public class Graph implements IGraph {

    ArrayList<ArrayList<Integer>> adjacent;     //adjacency list
    ArrayList<ArrayList<Integer>> inv_adjacent;     //adjacency list
    ArrayList<Integer> verticelist;             //mapping index of vertices -> id
    int[] vertice_map;                          //mapping id -> index of vertices
    int edgenum;

    public Graph(int n) {
        /*
         * Constructor.
         *
         * Input:
         *  + n: the maximum number of nodes (> 0).
         *
         * The node ids are from 0 to n-1.
         */
        adjacent = new ArrayList<ArrayList<Integer>>(n);
        inv_adjacent = new ArrayList<ArrayList<Integer>>(n);
        verticelist = new ArrayList<Integer>();
        edgenum = 0;
        vertice_map = new int[n];
        for (int i = 0; i < n; i++) {
            vertice_map[i] = -1;
        }
    }

    @Override
    public void addNode(int v) {
        /*
         * Add the given node with id v.
         */
        vertice_map[v] = verticelist.size();
        verticelist.add(v);
        adjacent.add(new ArrayList<Integer>());
        inv_adjacent.add(new ArrayList<Integer>());
    }

    @Override
    public void addEdge(int u, int v) {
        /*
         * Add the edge which goes from u to v.
         * Note that the graph is directed and
         * there is only one edge from u to v.
         * So please ignore this if you already have an edge
         * that goes from u to v.
         */
        adjacent.get(vertice_map[u]).add(v);
        inv_adjacent.get(vertice_map[v]).add(u);
        edgenum++;
    }

    @Override
    public int getNumNodes() {
        /*
         * Return the number of nodes.
         */
        return verticelist.size();
    }

    @Override
    public int getNumEdges() {
        /*
         * Return the number of edges.
         */
        return edgenum;
    }

    @Override
    public List<Integer> getNodes() {
        /*
         * Return the list of node ids.
         * If there are no nodes, return an empty list.
         */
        return verticelist;
    }

    @Override
    public boolean containsEdge(int u, int v) {
        /*
         * Return whether there is any edge
         * that goes from u to v.
         */
        return adjacent.get(vertice_map[u]).indexOf(v) != -1;
    }

    @Override
    public List<List<Integer>> getSCC() {
        /*
         * Return the list of strongly connected components (SCC).
         * An SCC would be represented as a list of nodes and
         * the node ids must be listed in ascending order.
         * For instance, if nodes (1,2,3) consist an SCC in this graph,
         * the list must be {1,2,3} and not {3,1,2}.
         * Also, the SCC list must not contain the same SCCs twice.
         */
        boolean[] visited = new boolean[verticelist.size()];//use index of vertice
        ArrayList<Integer> stack = new ArrayList<Integer>();// use index of vertice
        List<List<Integer>> scc = new ArrayList<List<Integer>>();
        for (int i = 0; i < verticelist.size(); i++)visited[i] = false;
        for (int i = 0; i < verticelist.size(); i++) {
            if (visited[i]) continue;
            dfs(i, visited, stack);
        }
        for(int i = 0; i < visited.length; i++)visited[i] = false;
        for(int i = 0; i < stack.size(); i++){
            int cur_idx = stack.get(stack.size() - i - 1);
            if(visited[cur_idx] == false){
                scc.add(new ArrayList<Integer>());
                inv_dfs(cur_idx, visited, scc);
            }
        }
        for(int i = 0; i < scc.size(); i++){
            sort(scc.get(i));
        }
        return scc;//sort
    }

    public void dfs(int n, boolean[] v, ArrayList<Integer> s) {//n is index of vertices
        v[n] = true;
        for(int i = 0; i < adjacent.get(n).size(); i++){
            int child = vertice_map[adjacent.get(n).get(i)]; //child is index of vertices
            if(v[child] == false)dfs(child, v, s);
        }
        s.add(n); //add index to stack
    }

    public void inv_dfs(int n, boolean[] v, List<List<Integer>> scc){//n is index of vertices
        v[n] = true;
        scc.get(scc.size() - 1).add(verticelist.get(n));
        for(int i = 0; i < inv_adjacent.get(n).size(); i++){
            int child = vertice_map[inv_adjacent.get(n).get(i)];
            if(v[child] == false)inv_dfs(child, v, scc);
        }
    }
    public void sort(List<Integer> l){
        int n = l.size();
        if(n < 2)return;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n - 1; j++){
                if(l.get(j) > l.get(j + 1)){
                    int tmp = l.get(j);
                    l.remove(j);
                    l.add(j + 1, tmp);
                }
            }
        }
    }
}
