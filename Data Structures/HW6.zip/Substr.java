

/*
 * Name: SEONGWOO KIM
 * Student ID #: 2016163055
 */

/*
 * Do NOT import additional packages/classes.
 * If you (un)intentionally use packages/classes we did not provide,
 * you will get 0.
 */

public class Substr implements ISubstr {
    String text;
    public Substr(String text) {
        /*
         * Constructor.
         *
         * Input:
         *  + text: the text where you will find the patterns.
         *
         */
        this.text = text;
    }

    @Override
    public int countPattern(String pattern) {
        /*
         * Input:
         *  + pattern: the pattern string
         * Job:
         *  Return the number of occurrences of the given pattern.
         */
        // I copied some code from class materials
        int n  = text.length();
        int m = pattern.length();
        if(n == 0 || m == 0) return 0;
        int[] fail = computeFailKMP(pattern);
        int j = 0;
        int k = 0;
        int count = 0;
        while(j < n){
            if(text.charAt(j) == pattern.charAt(k)){
                j++;
                k++;
                if(k == m){
                    count++;
                    k = fail[k - 1];
                }
            }else if(k > 0)
                k = fail[k - 1];
            else
                j++;
        }
        return count;
    }
    private static int[] computeFailKMP(String pattern){
        int m = pattern.length();
        int[] fail = new int[m];
        int j = 1;
        int k = 0;
        while(j < m) {
            if (pattern.charAt(j) == pattern.charAt(k)) {
                fail[j] = k + 1;
                j++;
                k++;
            } else if (k > 0)
                k = fail[k - 1];
            else
                j++;
        }
        return fail;
    }
}
